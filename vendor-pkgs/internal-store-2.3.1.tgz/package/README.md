# sync-store —— 使用手册（tutorial + API overview）

> 一个内容无关、安全的云同步存储库。你的 app 只跟**一个入口**打交道，碰不到底层。
> 行为以本文为准（本文 = 这份引擎的 SSoT）。标 ⚠TODO 的是已定、待实现。
>
> **复用规则（2026-08-13 包化，取代旧「互拷」制）**：本仓 = 引擎户口本体（@internal/store）；消费方 pin 版本化 tgz（见下节），不再互相拷代码。兄弟仓里的旧 baked copy 是待 cutover 的过渡态。

---

> 2.1.4：`createStore({ uploads: { resumable: true } })` = 上传会话落盘（> 4 MB 的分块上传刷新 / 被杀后接着传；默认关；详 `ai-docs/20261021-2.1.4-f19-heal-f54-resumable-upload.md`）。

> 2.3.0：**锁 / 星 / 收起**（家族「源文件原则上只读」，user 2026-11-08）。两个开关都默认关 = 2.2 行为：`createStore({ lockByDefault: true })` = 一等作品没解锁就 `save` 抛 `LockedError`（`files.unlock / lock / unlockOf / watchUnlocks`）；`createStore({ fileMarks: true })` = `files.star / unstar / fold / unfold` + `Item.starred / folded`，加了星的拒绝送进回收站（`StarredError`）。见下面 §2.2；详 `ai-docs/20261108-2.3.0-lock-star-fold.md`。

> 2.2.0：流式暂存区住自己的库 `${appId}.${databaseId}.staging`（主库旧 `staging/` 键由 `MIGRATIONS` v001 整批删）；MSAL authority 默认 `/consumers`、别的值直接拒（家规 #7）。详 `ai-docs/20261021-2.2.0-staging-split-authority-consumers.md`。

## 包与消费（@internal/store）

- 消费：库仓 `npm run release` 出 `internal-store-<ver>.tgz` → 拷进消费方仓 `vendor-pkgs/` **并 commit** → `"@internal/store": "file:./vendor-pkgs/internal-store-<ver>.tgz"`。升级=显式换 tgz。永不 workspace:* 跨仓、永不 git 依赖（自包含不变量：克隆任一 app 仓断网能构建）。
- **收货入口 = `scripts/pull-package.sh`**（2026-08-14 立，首个消费者 WebPaint cutover 后）：在**消费方仓根**跑 `bash "../20260813 internal-store/scripts/pull-package.sh" [版本]`——已发版 tgz（gh release 正货优先，离线 fallback 库仓根产物）落 vendor-pkgs/、package.json 指针换新、清旧 tgz、npm install。只认已 tag 版本；测试/commit 仍是宿主的活（脚本会打印清单）。
- 门牌：`@internal/store`（主入口）+ `@internal/store/testing`（mock 替身）。其余 deep import resolver 层拒绝。
- 宿主注入：MSAL（vendored 路径经 `configureOneDriveAuth({msalUrl})`）、加密 codec（`{zipPack,zipUnpack,pack7z,unpack7z}`，不注入=dormant，参考实现 `test/fixtures/`）、`StoreUI`（busy/resolveConflict/reportError/offlineEscape）。细节见下文各节。
- 体重（2026-08-13 实测）：进 app bundle **69 KB min / 24 KB gzip**；tgz 271 KB。build/release 自动报重。
- 机器参考 = `dist/index.d.ts`（人机分工 ADR-0023 条 7）；本文件 = 人读 SSoT。

## 0. 铁律（用了本库就必须守）

1. **禁止**直接碰 `localStorage`、`IndexedDB`、任何 cloud vendor（Microsoft Graph / MSAL / 裸 `fetch` 云端）。全部走本库。
2. 本库**零内容格式知识**——你的文件是 `.png`/`.glb`/`.pdf`/`.txt` 都一样，对库只是**不透明 binary blob**。库永不解码你的内容。（唯一例外：库懂 **zip 这种通用容器**，见 §2 `isZip`——那是容器机制，不是内容知识。）
3. **缺接口、库没实现你要的行为 → escalate to human 改库 API。绝不在 app 端绕过库自己实现。**
4. **不要 deep import 库内部文件**。只从主入口拿 `createStore` + 一个 provider（测试替身走 `@internal/store/testing`）。包时代这不再是约定而是物理事实：`exports` 门牌让 deep import 在 resolver 层直接 resolve 不到。
5. **API 难用是故意的**（§7）。觉得别扭、想绕——**停下 escalate**，别绕。
6. 对本库的修改，重构，API修改前，需要阅读`DATA SAFETY GUIDELINE.md`

> 为什么这么严：这个库存在的**唯一意义**是把红线数据安全（不丢、不静默覆盖、离线可读、冲突 surface、加密）**一次在库里保证好，每个兄弟项目开箱即得**。你绕过去，库就失败了。

---

## 核心心智模型（云同步逻辑——先读这段）

> 读懂这段就懂为什么 API 长这样。细节见 `DATA SAFETY GUIDELINE.md` + `CONTEXT.md`。

- **身份 = path/name**（格式无关、无 GUID）。云端「移动/改名」= path 变 → 别的设备看像「旧 path 没了 + 新 path 冒出来」。
- **离线第一公民**：`open`/`keepOffline` 自动把字节缓存本地（你不碰 IndexedDB），飞机上可读；列举失败/空列表**绝不据此删本地缓存**。
- **权威是 stateful**：本地 **dirty**（有未推编辑）→ 本地赢、云端不许盖；**clean** → 云端赢（新版自动快进下来）。**冲突 = `dirty ∧ 云端也动过` → surface（弹 sheet），绝不静默 LWW、绝不靠时间戳判新旧**。
- **每次推都带 If-Match = parentBase**（当前未推编辑分叉自的那个云版——不是「最后看到的云版」、不是共享 etag、不是时间）→ 陈旧设备的推必 412、安全 surface，绝不静默盖掉别人的新版。
- **删除/覆盖 = move-aside**：删→`.trash`、被冲突替下的旧版→`.backup`；本地副本进本地箱、云端副本进云端箱，**同层、绝不跨网**（可恢复）。脏字节绝不硬删。
- **本地副本去留（无 LRU）**：`keepOffline` 留一份、`offload` 丢——`offload` 只对「云端有完整副本的可重取 shadow」合法；本地是世界唯一副本（dirty / local-only / cloud-gone）时 offload **非法、抛错**。
- **cloud-gone 收敛**：曾同步的 **clean** 本地、云端 path 没了 → 降级 local-only（留着、不删）；**dirty** 孤儿 → 留着等处置。
- **红线全在深存储模块内 enforce，UI 永不自己保证**（UI 只渲染 store 在决策点回调出来的有限选项，见 §7）。

---

## 1. 唯一入口

```ts
import { createStore, createOneDriveProvider } from "@internal/store";

const { provider } = createOneDriveProvider({ clientId, msalUrl: "./vendor/msal/msal-browser.min.js" });

const store = createStore({
  provider,                                  // 必填：云端低层（OneDrive / mock provider）
  ui,                                        // 必填：UI 回调 bundle，store 在决策点回调进来（见 §7）
  appId: "my-app",                         // **必填**：本 app 在本 origin 内的唯一命名空间（见下「⚠ appId 红线」）
  docKinds: [                                // **必填表态**（0.16.0，§2.1）：本 app 有哪几种文档、各自以什么结尾、明文是什么容器。空数组 = 没有文档种类
    { kind: "book", suffix: ".webxiaoheiwu.zip", container: "zip" },
    { kind: "draft", suffix: ".txt", container: "raw" },
  ],
  autoCacheOpenedFile: true,                          // 选填(默认 true)：消费模式。true=开即自动留本地(读者/编辑器)；false=过路/流式(开整份拉云不落本地，§2；range 按需取片是 ⚠TODO 优化)
  // （旧 syncedSettingsFileName 已删 2026-07-13：设置/状态全走 store.collection，见 §4）
  validateAdopt,                             // **所有 consumer 必填，禁 placeholder/noop**：采纳云字节覆盖本地前验真内容（如验 PDF magic）。**库对加密透明 → 验的是解密后明文**。防损坏/captive-portal HTML 拿合法 etag 覆盖好本地=丢内容。
  // ── 加密（§5）：不加密就不给（dormant，省 1.6MB）──
  // crypto: myCodec,                        // 选填：app 注入的 zip/7z codec（不注入 = 加密不可用）
  // crypt: { getPassword, makePeek },       // 选填：非交互密码源 + peek 派生
  // （0.15.2 的 fileName / encFileName / toName / crypt.ext 四个命名回调 0.16.0 已删：全部由 docKinds 表推导，见 §2.1）
});
```
> **关于 `crypto`**：加密**逻辑**全在库内，唯一例外是重型 7z 引擎（wasm ~1.6MB）由 app vendor + 注入（包成 `crypto` codec）——体积大，不塞进每个 app 的 bundle。不注入 → 加密 dormant（packContainer 抛、其余照常；不加密的 app 就不 vendor，省 1.6MB）。KDF/GCM 走内置 WebCrypto，不用注入。
>
> **⚠ 命名空间根 `${appId}.${databaseId}`（同 origin 兄弟 PWA / 多 store 实例隔离）** > as-of 窄腰重构 2026-07-13：IndexedDB 和 localStorage 按 **origin** 隔离、**不按 path**（GitHub Pages `/app-a/` 与 `/app-b/` 同 origin）。库把**所有持久化标识收进一个命名空间根 `${appId}.${databaseId}`**（`databaseId` 默认 `"defaultStore"`；同一 app 想开多个互不打架的 store → 传不同 databaseId）：
> - **IndexedDB**：单库 `${appId}.${databaseId}`、单 object store `blobs`，key = `${partition}/${name}`（分区 `files/`·`trash/`·`backup/`·`collections/`，blob-partition 深模块）。
> - **localStorage**：经 `namespacedKv` 统一加根前缀的**唯一 choke point**——`${ns}.database-version`（schema 戳）、`${ns}.files.etag:`(cloud-sync files 实例)、`${ns}.files.dirty:`(local-head，文件 dirty 权威)、`${ns}.collections.etag:`/`.dirty:`(collections 实例)、`${ns}.settings.<key>`(散键裸值)、`${ns}.internal.pending_new_folders`/`_deletions`/`_uploads`/`_folder_deletions`/`pending_gone`。各深模块只用相对键，想漏都漏不出命名空间。
>
> **同 origin 的每个兄弟 PWA 必须用不同 `appId`**——否则两 app 读写同一份存储：文件互漏、schema 戳互踩跳迁移（显 0B）、缓存互毁。**根治自 2026-07-12 真机灾难**（详 `ai-docs/20260712-store-per-app-namespace.md`）。不传 `appId`/`databaseId` → 抛错，绝不静默共用。
>
> **🔒 持久化改动需同意（红线，2026-07-13）**：动**任何持久化数据结构、创建新字段**（localStorage + IDB 都算）**必须先显式获用户同意**——布局一上真机就有数据躺着，结构漂移=丢数据/裂卡/兄弟串号。

`createStore(config)` 返回**你 app 需要的一切**——你永远不自己构造 cloud / 本地缓存 / 集合。

**API 入口一览**（这就是你能碰的全部；其余都是内部深模块，碰不到）：

> as-of 2026-07-17（第 3 步 namespace 整顿）：文件域「非单文件」操作全收进 **`store.files.*`**；`file()` 的 `mode` **显式必填**；改身份走 **`file.tryMove(to)`**（不再 `store.tryMove`）；cloud-gone 收敛升级为**去抖后 send trash**（`store.files.reconcileAll`）。

| 拿到的 | 方法 | 章节 |
|---|---|---|
| `store.file(identifier, {mode})` → `RawFile`；`store.zip(identifier, {mode})` → `ZipFile`（只准 docKinds 里 container:"zip" 的种类，否则抛） | **`mode:"new"\|"existing"` 必填**（new=新建文档，撞名抛 `CloudNameCollisionError` 不覆盖；existing=打开已有）。`save · open · getHead({bytesLength,source}) · pullIfClean · tryMove(to) · trash · reupload · keepOffline · offload · isKeptOffline · isEncrypted · encrypt · decrypt · verifyPassword`（ZipFile 多 `getPeek({bytesLength,zipEntry,source})` + `decryptPeek(blob)`）。无 `rename`/`isDirty`——改身份走 `file.tryMove(to)`（结果式，含占用检查），dirty 经 syncState 读。`reupload()` = candidate-gone 的「重传」（本地 clean 字节 no-base 推回空 path） | §2 |
| `store.collection(name, {manual?, local?, getInitData?})` | **单例**（同名返同一对象）。`setItem · deleteItem · getItem(id,def) · getEntry · entries · keys · onChange · init · reconcileWithRemote · flushLocal · isDirty`（`{local:true}` = **不推云**的设备本地变体；`getInitData` = 新库 seed，uat=1；删除=value:null 墓碑） | §3 |
| `store.files.watchFolder(folder, cb)` | **唯一列举面**：订阅一个夹 → 立即本地帧、云端到了同一 cb 再闪（无 list/listAll/localKeys）。Item.syncState 含 `pendingGone`（cloud-gone clean 孤儿、防抖 grace 内） | §2 |
| `store.identifiers.parse(identifier)` / `.join({folder, stem, suffix})` | 身份的语法（0.16.0，§2.1）：切开 / 拼回去。gallery 和宿主都用它，别自己切名字 | §2.1 |
| `store.files.occupied(identifier)` → **boolean** | 身份占用（在线云端+本地都看，离线只看本地）。新建/另存/改名前预检（原 nameOccupied） | §2 |
| `store.files.ensureFolder · newFolder · deleteFolder` | 文件夹增删（删除「必须证实为空」库内强制；list 抛错/未权威→拒删） | §2 |
| `store.files.drainOfflineQueue()` | 离线队列统一重放（按序：新文件夹→新上传→删文件→删文件夹深→浅）；app 在 online/boot/reconnect 调 | §6 |
| `store.files.uploadStream(identifier, source, {onProgress?})` → `{status:"uploaded", size}` | **流式新建纯云端文件**（0.17.0，已实现）：宿主按 `source.read(offset, length)` 逐块给字节（本地 File、边加密的管线……），库逐块上传（上传会话，最后一块落地才成文件），**整份永不进内存、不落本地、不写谱系**。只准新建：身份已占 → 抛 `CloudNameCollisionError`，一个字节不传；离线 / 未登录 → 抛。成功后 cloud-only，之后 `open()` 照常。`save(bytes, {onProgress})` 同样透传上传进度（0.17.0） | §2 |
| `store.files.listTrash · listBackup · restoreTrash · purgeTrash · emptyTrash · emptyBackup` | 回收站/备份箱：**本地↔云聚合**列举（TrashItem：side/encrypted/conflictLive，只元数据无 blob）·恢复·彻底删·清空 | §2 |
| `store.files.reconcileAll({activeIdentifier?})` | **全库** cloud-gone 收敛（仅用户显式指令）：clean 孤儿**去抖后 send trash**（首次见 gone 标 candidate、跨 ~24h GRACE 第二次+ 才动手；重现/被编辑自愈）。日常开夹惰性收敛走 watchFolder 内的 per-folder reconcile（同 converge SSOT） | §6 |
| `store.encryption.*` | **裸字节**级加密面（文件还没进 store、无 name 可查时）：`isEncryptedBlob`（便宜嗅探）· `tryDecryptEncryptedBlob`（验+解**合一**，null=错密码）· `isEncryptedPeekBlob` | §5 |
| 加密（at-rest） | config 注入 `crypto`(zip/7z codec) + `crypt`(ext/makePeek/getPassword)；透明封解 + `file.encrypt/decrypt/getEncryptedBlob`；不注入 = dormant | §5 |

---

## 2. 文件 store —— 一个名字一个文件

```ts
const f = store.file("papers/Wei 2011.pdf", { mode: "existing" });   // mode 必填：existing=打开已有、new=新建
await f.save(bytes);          // 落盘 + 按节律推云（If-Match 守冲突）。mode:"new" 首存撞名 → 抛 CloudNameCollisionError（不覆盖）
const blob = await f.open();  // 本地有则秒开；无则拉云 + 缓存本地（下次离线可读）
await f.tryMove("papers/new.pdf");   // 改身份/移动**唯一入口**（含 occupied 占用检查，结果式 {ok:false,where} 不抛）
await f.reupload();           // candidate-gone「重新上传」：本地 clean 字节 no-base 推回空 path（撞名→collision surface；成功→synced）
await f.trash();              // 移进回收站：本地副本→本地 .trash / 云端副本→云端 .trash（各自 move-aside，可恢复）。2.1.2 起叫 trash（原 delete）
```
- **新建文件 = 对一个新 name `file(name,{mode:"new"}).save`**（没有单独的 create）。云端已有同名但内容不同 → 抛 collision，绝不覆盖。
- **delete vs offload**：offload 只丢「可重取的 shadow」、云端不动；delete 是**销毁**。delete 内部按原子态分流——本地若是 offloadable shadow → 硬删本地（云端 .trash 已救着，不留双份）；本地若是唯一副本（dirty/local-only）→ 先变 local-only 再进**本地** .trash（未推字节可恢复，绝不硬删）。云端副本进**云端** .trash。两套 trash 各管各、不跨网（ADR-0015）。
- **`open` 自动把字节缓存本地**（离线可读，你不碰 IndexedDB）。本地有副本的 `open` 先做一次新鲜度检查（一趟 `fetchMeta`）；**0.17.0 起**，`watchFolder` 刚拿到的**完整**云端帧算作证据（30 s 内、且帧里的 etag 等于本 tab 已见的 base 时）——连着 open 几十个刚列过的小文件不再逐个问云端；帧说云端动了的一律不采信、照常问（证据可能比自己刚推的还旧）。
- **`autoCacheOpenedFile:false`（流式消费 app：3D 模型/电台类）已实现**：`open` 本地有就读本地、没有就**整份拉云、不落本地**，只显式 `keepOffline` 才整份落地。
- **`file.openStream()` 流式面（A1/A2，2026-08-15）**：大媒体按需取片——本地有副本走本地切片；无则开**分片下载会话**（2MiB 分片，按 eTag 钉版，拉到即落 `staging/` 暂存区 = tee）。句柄 `{ totalSize, read(off,len), prefetch(off,len), keep(), close() }`：`read`=播放优先级；`prefetch`=低优先（下一曲头部预拉）；`keep()`=升格正式本地副本（≡ keepOffline：**复用已流分片只补缺口，先播后 pin 不重下**）。调度全局一域：播放分片在飞时 **pin 严格串行且让路**（不 spike）。at-rest 字节面（加密件给密文；流式消费请只用于明文文件）。staging 是加速器不是正确性依赖（受全局 cap FIFO 兜底、坏了照样直连流）。
  - **2.0.0 `createStore({ streaming })` 显式开关（不传 = 上面的 0.18 行为）**：`lanes` 投机车道数（prefetch / keep 补缺口并行几路；播放不限）；`stallMs` 卡住判定（一路连续多久**没到一个字节**——播放的读再开一路对冲、先到的赢，投机的中止让道、这次 `prefetch` 以 `StreamStallError` reject）；`mirrors` 替代来源（`createFileMirror` 本机文件 / `createHttpMirror` 局域网 / Tailscale 主机；身份仍归云端 item，第一片先和云端比过再交，之后抽样比，不一样整个丢掉）。开了之后 `prefetch()` 失败如实 reject。`FileStream.status()` 零网络快照（在飞 / 排队 / 卡住 / 镜像状态，状态条用）。它只影响资源那台引擎；作品那台（save / push / 冲突面）按构造不受影响（两台互不 import，`test/engine-boundary-guard.test.mjs` 守着）——任何 app 流三等资源（电台的音乐、参考窗的视频、KudsRocket 的大文件）都可以传（user 10-17「艺术类 app 不传 streaming 也许需要视频参考呢」）。公民四等的 SSoT = 家族根 `ai-docs/20261016-data-safety-model.md` §2。细节 `src/stream/download-session.ts` / `src/stream/chunk-scheduler.ts` 头注释，发版说明 `ai-docs/20261017-2.0.0-streaming-lanes-stall-mirrors.md`。
- **列举唯一面 = `store.files.watchFolder(folder, cb)`**（订阅一夹→本地帧+云端帧同一 cb；无 `list`/`listAll`/`localKeys` 公开面）。snapshot `{ path, items, folders, complete, stale? }`，`complete:false` **别据此删缓存**。
- **冷首帧目录索引缓存（A3，2026-08-15）**：每夹「上次完整云帧」持久化在 `dir-index-cache/` 分区（**非 SSoT，脏的**，只配画首帧） → 本地帧自动追加**上次所见的 cloud-only 缺项**（首帧不再近空、无需等网络）。掺了快照的帧带 `stale:true`（可能过时，云端帧到达即纠偏）。纪律：快照**只作显示**——绝不喂 reconcile/cloud-gone 判定、绝不改写本地项的 badge；登出视角不掺快照。同批修复：一次订阅只打**一遍** Graph（此前 reconcile+listing 各拉一次）。
- `store.files.reconcileAll({activeIdentifier?})` — **全库** cloud-gone 收敛（仅用户显式指令）：曾 synced 的 clean 孤儿 → **去抖后 send trash**（首次见 gone 标 candidate、跨 ~24h GRACE 第二次+ 才动手；重现/被编辑自愈；`activeFileName` 跳过当前打开的 doc）。日常开夹惰性收敛走 watchFolder 内的 per-folder reconcile（同 converge SSOT）。dirty/从没同步/partial-or-空列表 一律不动。详见 CONTEXT.md。

### 离线副本 —— keepOffline / offload（无 LRU、无 pin）

```ts
await f.keepOffline({ onProgress });   // 留一份离线副本（未缓存则**分片会话**下载：复用 staging 已流分片只补缺口 + 字节进度回调）
await f.offload();        // 移除本地副本（只删本地，云端不动）。**非法时抛错**，见下
await f.isKeptOffline();  // 本地有副本？（= 已留作离线；无 localKeys 批量面——离线可读性经 watchFolder 的 item.syncState 判）
```
- **心智模型**：有本地副本 = "kept offline"。无 LRU、无 pin、无 unpin、无 force——只有「留一份」(`keepOffline`) 和「移除」(`offload`)；中间「可被自动驱逐的 cache」态**不存在**（开了 / 下载了就留着，直到显式 `offload`）。
- **offload 只对 shadow 合法**：本地副本是「云端某完整版的可重取镜像」时，offload = hardDelete（**不进本地 trash**，可重下）。合法 = `clean ∧ 在线 ∧ 已登录 ∧ 曾 synced ∧ 云端仍有完整副本(size>0)`。cloudMoved（云端被别人推了新版）**仍合法**（clean 本地下次 open 会快进）。
- **非法 offload = 内部错误（banner），不是软保留**：本地是**世界唯一副本**（local-only / 未上传 / dirty / forked / cloud-gone / 离线）时，它不是谁的 shadow，offload **不适用** → 抛 `OffloadIllegalError`，经 ui.reportError 出 banner。UX 不该暴露非法 offload；要清掉唯一副本走的是 **delete** 语义，不是 offload。
- `autoCacheOpenedFile:true`（默认，见 §1）下 `open` 即自动留本地；`autoCacheOpenedFile:false` 流式消费则 `open` 过路不留（整份拉云不落本地；按需取片走 `openStream()`），只有显式 `keepOffline` / `openStream().keep()` 才落地。
- **`readOnlyFiles:true` 只读镜像变体（A4，ADR-0022 预排）**：BR 类消费者（内容由用户经 OneDrive 客户端投放，app 永不写）。files 一切写路径（save/tryMove/delete/reupload/encrypt/decrypt、建删夹、回收站恢复/清空）抛 `ReadOnlyFilesError`；**collections 照写**（阅读/播放位置）；读与离线副本面（open/openStream/keepOffline/offload/watchFolder/reconcileAll）照常。

### 回收站 / 备份

```ts
store.files.listTrash();    store.files.listBackup();               // 列回收站 / 备份（**本地↔云两端聚合**的 TrashItem[]：side/encrypted/conflictLive，只元数据无 blob）
store.files.restoreTrash({ trashKey, fromCloud, cloudItemId, targetName, encrypted });   // 恢复（side-aware：both 两腿都恢复，云端腿撞名自动 (2)）
store.files.purgeTrash({ trashKey, cloudItemId, confirm });         // 彻底删除（confirm 回调确认）
store.files.emptyTrash({ scope: "both" });                          // 清空回收站（"local" | "cloud" | "both"）
store.files.emptyBackup({ scope: "both" });                         // 清空备份箱（同 scope；gallery 0.8.6 起搁置区视图顶上有「清空…」钮）
```
- `trash()`（2.1.2 前叫 `delete()`）把文件移入回收站（可恢复）；版本冲突时被替下的旧副本进备份（不丢）。`TrashItem.conflictLive`=离线删被回线 edit-wins 撤销→本地 trash 有、云端还活着（两存，UI surface）。

### 2.1 身份的语法：`docKinds` 表 + `store.identifiers`（0.16.0）

> 提案与用词出处 = `ai-docs/20260929-proposal-doc-types.md`（user 2026-09-29 批）。用词：**identifier 身份 / folder / stem 主干 / suffix 后缀 / kind 种类**，别混用 name / path / 扩展名。

**身份（identifier）** = 库对外说的「这是哪一份文档」，形如 `文件夹/主干后缀`：`草稿/第一章.txt`、`樱川.webxiaoheiwu.zip`。一个库里唯一；改名或挪文件夹就是换身份（`tryMove`，`files.onRenamed` 发事件）；加不加密、在哪台设备、上没上云它都不变。它**不是**云端真实路径：加密的稿在云端叫 `稿.txt.zip`，那是底下那一层的事，宿主看不见。

**表报一次，其余推导。** `createStore({ docKinds })` 必填：每行 = 一种文档怎么拼（`suffix`，含点，可以多段，**整串比对不数点**，大小写不敏感）、是什么容器（`container: "zip" | "raw"`）、app 自己的标签（`kind`，开放集，库原样带着不解释）。空数组 = 明确声明没有文档种类。表有歧义（某个后缀去掉结尾 `.zip` 之后和表里另一个后缀互为结尾；或光秃秃的 `.zip`）→ `createStore` 当场抛。

**公民等级也在这张表里（2.1.0；user 2026-10-17「能kind和等级绑定吗（允许一kind多等级？)然后ctor的时候传死」）。** 每行可带 `tier`：不传 = `"work"`（一等作品，= 2.0 的全部行为）；`"auto-backup"` 二等自动备份——库**永不弹面**，412 / 撞名 / open 时云端变了一律这台的赢，输的那份不进备份箱，干净副本碰上云端没了就跟着云端；`"resource"` 三等资源——`save / tryMove / delete / reupload / encrypt / decrypt / rekey` 全抛 `ReadOnlyFilesError`，`open` 过路不留本地，云端没了本地缓存直接丢（不进回收站），读走 `openStream / keepOffline`。等级是**行的属性、createStore 时传死**，没有按次调用改等级的口（那就是越狱）。一个 kind 要两种等级就声明两行：同 `suffix`、不同 `stem`（正则，匹配主干；带 stem 的行按声明顺序先试，都不中落到那个不带 stem 的行；一个后缀最多一行不带 stem）。每行还可带自己的 `validate(plain)`（没带用 `validateAdopt`）。四等表的 SSoT = 家族根 `ai-docs/20261016-data-safety-model.md` §2；第四等「设备状态」不进文件 store。例（KudsRocket 形状）：

```ts
docKinds: [
  { kind: "snap", suffix: ".crumb", container: "raw" },                                              // 手动格 = 一等
  { kind: "snap", suffix: ".crumb", container: "raw", tier: "auto-backup", stem: /-[ah]\d+$/ },      // 自动格 / 历史份 = 二等
  { kind: "asset", suffix: ".pack", container: "raw", tier: "resource" },                            // 大资源 = 三等
]
```

从这张表推导出来的（0.15.2 之前是七八个各答各的回调）：

| 问题 | 答案从哪来 |
|---|---|
| 这个身份是不是文档、主干在哪、后缀从哪开始 | `store.identifiers.parse(identifier)` → `{ identifier, folder, stem, suffix, kind, container } \| null` |
| 改名 / 复制 / 挪文件夹 / 撞名加戳 | 切开，换一格，`store.identifiers.join({ folder, stem, suffix })` 拼回去 |
| 云端那个名字是不是加密容器 | 库内：去掉结尾一个 `.zip`，剩下的认得是文档 → 是 |
| 这份能不能 `getPeek` | `store.zip(identifier)` 只准 container:"zip" 的种类，否则抛；别的一律 `store.file()` |
| 从回收站 / 备份箱取回撞名叫什么 | 主干后面接 ` [yyyymmdd-hhmmss]`，后缀不动：`书 [20260929-143200].webxiaoheiwu.zip`，本地云端两条腿一样 |
| 哪些能加密 | 只有声明过种类的文档（非文档封了云端名认不回来），否则 `encrypt()` 抛 |

```ts
const d = store.identifiers.parse("草稿/樱川.webxiaoheiwu.zip");
// → { identifier: "草稿/樱川.webxiaoheiwu.zip", folder: "草稿", stem: "樱川", suffix: ".webxiaoheiwu.zip", kind: "book", container: "zip" }
store.identifiers.join({ folder: "草稿", stem: "樱川 副本", suffix: ".webxiaoheiwu.zip" });   // 复制：只动主干
```

`store.file()` 收任何身份（文档、图片、杂物）；`store.zip()` 之上多 `getPeek` / `decryptPeek`：

```ts
const raw = store.file("a.pdf", { mode: "existing" });   // RawFile：save / open / getHead / tryMove / encrypt / getEncryptedBlob …
const zip = store.zip("a.webxiaoheiwu.zip", { mode: "existing" });    // ZipFile：多 getPeek
const p = await zip.getPeek({ bytesLength: 131072, zipEntry: "Thumbnails/thumbnail.png", source: "local" });
                                  // 一次尾片（本地切片或云端 byte-range）+ 库内 zip 解析，取该 entry 的 peek 字节，不全量下载
```
- `RawFile`：原始字节直存（云端文件 = 原始内容，双击能开，守 anti-abandonware）。**无预览图**。
- `ZipFile`：库把 zip 尾片解析全包（**你不写任何 zip 代码**）。`getPeek({bytesLength, zipEntry, source})` 返明文 entry 的字节／或加密容器的**密文** peek（`ENC_PEEK_MIME`，不解密，供你缓存原样存密文=明文不落 IDB），`decryptPeek` 用内存密码解。
- **`file.getHead({bytesLength, source})` 头片 peek（0.15.0，首个消费者 CatsUp `.glb` 封面）**：文件**开头** n 字节的明文 Blob（无 type，格式盲）——「头在前」格式（GLB / PDF / ID3 / RIFF）的预览面；「目录在尾」的 zip 走 `ZipFile.getPeek`。本地有 → `Blob.slice` 零网络；无 → 云端 byte-range **不整份下载、不落本地**。`source` 必填同 getPeek（"cloud" 绝不落回本地）。**加密件 → null**（密文外壳不是头片，库绝不为预览解密）；云端不可达 → **抛**（未知 ≠ 没有，缓存层据此不缓存）。
- peek/预览是**格式无关的不透明 binary blob**（jpg/png/随便，库不看、不构造、不解码）。

---

### 2.2 锁 / 星 / 收起（2.3.0；两个开关都默认关）

> as-of 2.3.0 / 2026-11-08。家规 = 家族 `CLAUDE.md`「源文件原则上只读：手动解锁才能改」。**每个 app 专门迁移一轮才打开开关，不许顺手开。**

**锁（`createStore({ lockByDefault: true })`）**——一等作品（docKinds 里 tier `"work"` 的文档）默认只读，这是三层里的最后一层（界面不收输入 → app 的保存拒绝并报错 → 库拒绝写入）。

| 动词 | 没解锁时 |
|---|---|
| `file.save`（改已有的） | 抛 `LockedError`（任何副作用之前：不标脏、不落盘、不打网）。成功的 save 把过期往后推 |
| `file.save`（`mode:"new"` 的首存） | 不拦（新建不是改）。存成后带一枚解锁；`save(…, { bornLocked: true })` = 生来锁着（存下来的一版、导入的文件） |
| `tryMove` / `trash` / `encrypt` / `decrypt` / `rekey` | 不归锁管（改名、删除、加密算档案那头；删除归星） |
| `pullIfClean` / `resolve()` / `dirty.pushAll` / `reupload` / 离线补推 | 不归锁管（同步的是已经存下的字节，不是改内容） |
| 图片、杂物（不是声明过的文档）、二等自动备份、三等资源 | 不受影响 |

- `files.unlock(identifier)` → `Unlock { identifier, unlockedAt, expiresAt }`。**只许由人的手势调用**——代码替人解锁 = 这把锁白装（各 app 守卫测试钉）。`files.lock(identifier)` 提前收回；`files.unlockOf(identifier)` 同步现算；`files.watchUnlocks(cb)` 订阅当场给一次全表、之后有变化再给。
- 一枚解锁：逐件、**只记在这台设备的 kv（`internal.unlocks`），永不进任何同步面**；放凉 `unlockTtlMs`（默认 24 h）过期，滑动——`expiresAt = max(解锁那刻, 最近一次成功的 save) + ttl`；`activeIdentifier()` 指着的那份过期不打断，它不再是活动文档的那一刻才落锁。改名 / 移动成功解锁跟着走；进了回收站解锁不留。
- **和「no-timestamps」红线的关系**：那条红线说的是内容的新旧、谁覆盖谁从不看时间戳。这里的时间只决定**这台设备此刻让不让改**，不参与任何同步 / 合并 / 新鲜度判断；它是防误触的保险，不是安全边界，**不是把时间戳引进同步决策的先例**。本机时钟被往回拨过 → 一看到就把那条改记成现在，最多再等一个 ttl。
- `files.lockByDefault`（布尔）= 开关的原值，前端据此决定画不画锁。四个动词本身不受开关影响（开关只决定 `save` 拦不拦）。

**记号：星 / 收起（`createStore({ fileMarks: true })`）**——记在一份库自己的 collection 里（云端 `.${appId}/store.file-marks.json`；逐条合并、带墓碑、If-Match，和 §3 同一套设施）。条目 = 身份 → `{ starred?, folded? }`。

- `files.star / unstar(identifier)`：加了星的，库拒绝送进回收站——`file.trash()` 抛 `StarredError`；`resolve()` 的面里人选「云端覆盖本地 = 这份进回收站」→ `{ status: "unresolved", reason: "starred" }`，两边不动；云端那份没了、过了 24 h 宽限，机器也**不**自动送回收站，停在 `pendingGone`（要你处理），撤星后下一轮照常收敛。记号读不出来 → 拒绝删除（响亮），不放行。
- `files.fold / unfold(identifier)`：**纯显示记号**。库照常列出它、不拦任何动作；图库拿 `Item.folded` 决定画不画成一条细条。「存下来的一版」那种收起靠名字（`<主干>.backup-<日期>`），是图库认的，库零命名知识。
- 列举：`Item.starred` / `Item.folded` 只在 true 时写；记号变了（这台改的、别的设备同步来的）那一夹自动重画。改名 / 移动成功记号跟着新身份走。文件进了回收站，条目留着不动。
- 它是人的决定，不是能重建的缓存。**已知的洞**：记号那份文件丢了 = 星没了（保护失效，作品不丢）、手动收起的重新露出来；两台设备离线各点一次 = 逐条后改的为准；别的设备（或同一台的另一个标签页）还没同步到这颗星之前，在那边照样删得掉；没更新的旧版 app、网盘自己的网页拦不住。
- **回收站不连坐（2.3.1）**：加了星的东西照理进不了回收站，会在里面只有一种情况——别的设备（星还没同步到 / 旧版 app）把它删了进去。这台 `emptyTrash` 跳过它并在结果的 `kept` 里报出来，`purgeTrash` 对它抛 `StarredError`；人可以还原，或者撤星后再删。本地腿按原身份精确认；云端腿只有带戳的文件名、没有原来的文件夹，所以按文件名认，同名的一律留（往留的方向错）。记号读不出来 → 拒绝清空 / 彻底删。备份箱不受影响。
- `files.fileMarks`（布尔）= 开关的原值。没开时四个动词抛、列举不带这两个字段、云端不建那份文件。

**后端无关**：锁 = 本机一条 kv；星 / 收起 = 一份普通的同步文件。没有用到任何一家后端特有的功能。

## 3. 集合 store —— 一个 JSON 装多个**原子** item

> （旧名 `folder-store` 是误导：它不是文件夹，是「一份同步 JSON、里头一堆带 id 的 item」。**已改名 `collection`**。）

> as-of 2026-07-14：信封字段 `payload`→`value`、写面 `upsertItem`→`setItem`、读面加 `getItem(id, default)` + 浅拷贝隔离 + `onChange`。
> as-of 2026-07-17：删除改 **value:null 墓碑**（LWW，替代 trash/resetAt）；`setItem(id, undefined)` **报错**；`pullAndReconcile`→`reconcileWithRemote`；删 public `flush()`（云推由 reconcileWithRemote 兜底，`flushLocal()` 保留）；加 per-collection **`getInitData`**（新库 seed，uat=1）。旧名已删（本节即当前 API）。

```ts
const reading = store.collection("reading-state", { manual: true });   // manual=你控制推云时机（reconcileWithRemote 驱动 commit）；不传=编辑后自动防抖推
                                                                       // { local: true } = **不推云**（≠"开缓存"：synced 变体也写 IDB）；reconcileWithRemote no-op
                                                                       // { getInitData: () => [{id, value}] } = **仅 json 不存在（新库）时**调，填初始值（uat=1）
await reading.init();                                        // **必须先调**：先 hydrate 本地(快) → 后台 fire-and-forget 拉云对齐 + 新库 seed。init 前 setItem 抛、getItem 恒返 default
reading.setItem(docId, { pageIndex, yFraction });           // 新增 / 整条原子替换（id 必填；value = 任意 JSON，裸值或对象；**value===undefined 报错**）
reading.deleteItem(docId);                                  // ≡ setItem(docId, null)：null 墓碑=明确删除指令，LWW（删得晚→删掉、别处编辑得晚→复活）
reading.getItem(docId, defaultVal);                         // 读 value（无值 / 墓碑 → default；default 可为裸值或**共享**工厂 fn，⚠工厂 lambda 别 inline）
reading.getEntry(docId);                                    // 带 uat 的完整 entry { id, uat, value } | undefined（墓碑→undefined）
reading.entries();                                          // 全部 entry（数组，过滤墓碑）
reading.keys();                                             // 全部 id（数组，过滤墓碑）
const off = reading.onChange((ids) => {/* 云端对齐带来值变 */});   // 整库订阅；或 onChange(id, cb) 绑单 key（返退订）
await reading.reconcileWithRemote();                        // 事件驱动重拉 + resolve（local newer/pending 一并 push）；flushLocal() 只落本地（卸载兜底）
```
- 用于：阅读位置表、预设架、设置/状态、任何"一堆小条目、跨设备合并、零冲突"的东西。app 每类持久化建一个 collection（见 §4）。
- **不传 `encode/decode`**：value 是普通 JSON（裸值或对象），库自己序列化（content-agnostic 是给 §2 file 的不透明 blob；collection 本就是结构化可合并 JSON，库懂它的信封）。
- **信封由类型强制，不靠约定**：库内部把每条包成 `{ id, uat, value }`——`id` 必填；`uat`（合并时间戳）**库内部盖戳，app 既传不进也看不到**（顺带守"内容里不放 timestamp"红线）；`value` = 你给的裸值/对象（`null`=墓碑）。
- **getItem/setItem 两侧 value 浅拷贝隔离**：拿到的对象原地改、或传入的对象事后改，都不与库内信封互相污染（浅拷贝语义——深层嵌套要改整枝替换再 setItem）。
- **item 是原子的：只有 `setItem`（整条替换），没有 partial update。** 想改一个字段 = 取整条 → 改 → 整条 setItem。换来合并简单 + 无中间态。
- **删除 = 墓碑**：`deleteItem(id)` 写一条 `value:null`，带 uat 参与 LWW（删/编辑谁 uat 大谁胜）。墓碑留在库里跨设备传播删除、读面过滤——**无独立 trash 集合、无 resetAt 水位线**（时钟同步误差=已知风险，分钟级不成问题）。
- 内部按 item 合并，**逐 item last-write-wins**（每 item 各带 uat，并发改不同 item 都不丢；同 item 并发 = 静默 last-win，**仅配置类可接受**，画作 content 绝不走此路，走 §2 file 的 If-Match）。
- **新库 seed（eager）**：`getInitData` 在 **idb 无此 collection**（新库）时立即调，填初始值 uat=1（最低戳）。随后 init 后台 reconcile 拉云——**云端/别设备的真数据（uat>1）经 LWW 必胜过 seed、覆盖**；云端确实空则 seed 推上去。离线新设备照样立即有内容；在线新设备先显 seed、云端到了再覆盖。store 内容无关：app 域构造 `[{id, value}]`（如预设架把 builtin-presets.json 映射进来）。
- **自动本地缓存**：离线、重新打开、意外关闭后都能读到上次的数据（你不碰 IndexedDB）。init 后台对齐云端、值变经 `onChange` 通知；事件驱动（focus/visible/online）重拉调 `reconcileWithRemote()`。页面卸载时调一次 `flushLocal()` 把最新状态落本地。
  > ⚠ 名字别搞混：collection 的重拉叫 **`reconcileWithRemote()`**（pull+push）；`store.file(name).pullIfClean()` 是 **file** 那一面的新鲜度检查（clean 快进），两回事。

---

## 4. 设置 / 状态 —— 每类持久化建一个 collection（你**不碰** localStorage）

> as-of 2026-07-13：`localSettings`/`syncedSettings` 已删。设置/状态**全走 §3 collection**——app 为每类持久化建一个 collection，直接用其 KV 面。无第二份数据结构、无中央 registry、无保留名。

两条正交轴，各建一个 collection：
- **设备本地 vs 跨设备** → `{ local: true }`（只走 IDB、永不碰云）vs 默认（synced）。
- **user-preference（跟人/设备的偏好）vs app-state（跨文件持久态）** → 语义分名，不同 collection。

典型宿主建四个（app 层，非库硬编码）：

```ts
// 设备本地偏好（theme…）——local:true，不上云
const localUserPref  = store.collection("local-user-preference",  { local: true });
// 跨设备偏好（lang/手势/fps/pixel-grid…）
const syncedUserPref = store.collection("synced-user-preference");
// 跨设备 app 态（current-directory/current-file…）
const syncedAppState = store.collection("synced-app-state");
// 设备本地 app 态
const localAppState  = store.collection("local-app-state", { local: true });

syncedUserPref.getItem("lang", "en");        // 直读（缺省 default；DEFAULTS 放 app 一处 SSoT，别处不 inline）
syncedUserPref.setItem("lang", "zh");        // 直写（同步内存 + 防抖持久化 + 后台推云）
syncedUserPref.onChange("lang", () => {/* 云端对齐把别台设备的改带回 → 热重贴 */});
```
- **default 放 app 一处 SSoT**（一个 DEFAULTS 对象），别每次取值各写各的 default → 不一致。
- **boot 门**：app 在 comp-root 前 `await collection.init()`（内部 hydrate 快、离线 OK、不碰网）→ 让 eval 期就要值的 lang/theme 读到 hydrate 后的值；云端后台对齐、`onChange` 通知（非默认语言用户不双载）。
- **collection 名 = 合法文件名、不带后缀**（`synced-user-preference`/`preset-rack`）；store 映射云端自动追加 `.json` → `.${appId}/<name>.json`。已无保留名（`settings` 不再保留）。

---

## 5. 加密 —— 逻辑在库，对 app 透明（已实现）

> ### 🔴 红线：解密后的明文永不落任何持久层
>
> **加密作品的明文字节 / 图层位图 / 及其缩略图派生，只能存在于内存，永不落任何持久层。**
> 持久层 = IndexedDB（含本库的 `blobs`）、localStorage、checkpoint/快照、导出文件、任何缓存。
>
> 库已经在这么做，别拆：
> - 每次本地写前 `seal.sealForWrite` 包壳 → **IDB 里也是密文**，不只是云端；
> - 无密码 → 抛 `LockedError`，**绝不静默降级存明文**；
> - `unsealForRead` 只返内存 Blob；
> - `getPeek` 对加密件返**密文** peek（`ENC_PEEK_MIME`），**库绝不为了缓存去解密**——
>   app 原样存密文，要显示时再 `decryptPeek` 解到内存；
> - 本地缓存记录**没有任何缩略图/预览字段**。曾有个 `.peek`（零 reader），
>   对加密件把 256px 明文缩略图写进了 IDB，2026-07 已删——**别再加回来**。
>
> 加它之前先问：这坨字节是不是某个加密作品解出来的？是 → 只能在 RAM。


> 加密**逻辑**（3 层容器 / KDF / peek 验证器 / 透明封解）全在库内。重型 **7z(1.6MB wasm)+zip codec 由 app 注入**（不塞每个 bundle）。不注入 → 加密 dormant（不加密的项目省 1.6MB）。密码**非交互**：库永不弹框（§7），app 持密码 + 解锁循环在 busy 外。详见 `ai-docs/11`。

```ts
const store = createStore({
  provider, ui,
  crypto: myCodec,                          // app 注入 zip/7z codec（参考实现 = 本仓 test/fixtures/）
  crypt: {
    ext: "ora",                             // 真扩展名 → 还原真名
    getPassword: (name) => cryptoState.get(name),   // 同步、非交互、只读内存（唯一密码源）
    makePeek: async (plain) => thumbBytes,  // 明文→不透明 peek（如缩略图）；自动加密进容器尾部
  },
});
```
- **透明封解**：照常 `f.save(bytes)` / `f.open()`，库按文件 at-rest 态自动加/解密（SSoT=字节本身）。未解锁（无/错密码）→ `open` 返 `null`、`save` 抛 `LOCKED`（**绝不静默存明文**）。
- **at-rest 切换**：`f.encrypt()` 明文→密文、`f.decrypt()` 密文→明文。红线：先本地落地、再云端 If-Match 跟进；失败标脏锚 parentBase 交 push 流接力（绝不只换一端=静默撤销加密）；曾同步但离线→拒；错密码在任何持久改动前出局。
- **换密码**（0.12.0，user 2026-09-09「保留换密码，加 api」）：`f.rekey({ newPassword })` 密文→密文：旧密码经 `getPassword` seam 非交互解、新密码显式传入、内存重打包、只把**新容器**推云。宿主换密码**必须走这个**，不许 decrypt()→encrypt()——那条路把明文推上云（OneDrive 版本历史会永久留一份明文；中途断网 = 一批文件停在明文态）。status 同 encrypt：swapped / cloud-deferred / conflict / offline / locked / no-local / not-encrypted。
- **解锁循环（app 在 busy 外做）**：`f.verifyPassword(pw)` 便宜验（解 peek，不碰 7z）→ app 自己存密码 → 重跑 flow。
- **预览**：`ZipFile.getPeek({bytesLength, zipEntry})` 取尾片 + 库内 zip 解析该 entry（本地切片或云端 byte-range，不全量下载）。明文→PNG blob；加密→**密文** peek blob（`ENC_PEEK_MIME`，不解密→你缓存原样存密文=明文不落盘）；密文再经 `decryptPeek(blob)` 非交互解（内存密码；锁定→null）。写侧 peek 经 `crypt.makePeek` 自动派生（无显式 `setPeek`）。
- **导入辅助**（文件还没进 store、无 name 可查 peek）：`store.encryption.isEncryptedBlob(blob)` 便宜分流 →
  `store.encryption.tryDecryptEncryptedBlob(blob, pw)` **验+解合一**（null=错密码）。
  合一是刻意的：拆成「先验再解」会把整份内容用 7z 解**两遍**（旧 `verifyContainer`+`unsealWith` 正是这个毛病）。
- **读 at-rest 密文**（导出/拷贝/快照要原样搬密文、不能解壳）：`ZipFile.getEncryptedBlob()` → `EncryptedBlob | null`。

> **未采用**：README 早期草拟的 `store.encryption` **超集**（库统一密钥 + `vault.salt` + `encrypted:true` + `saveEncrypted` + `addEncryption`）本版不实现
> —— 注意别和 v415 落地的 `store.encryption`（只有三个**裸字节**级 helper，无密钥管理）混为一谈；那个是窄面，这个是被否掉的宽面——对齐前身引擎真机验过的 `getPassword`/`encrypt` 模型（出处 = WebPaint ai-docs/11）。要库统一密钥再单独 escalate。

---

## 6. 大概做了什么（红线在库内 enforce，UI 永不自己保证）

push-serialize（每文件串行推）· If-Match（每次写带 etag，412 → surface 冲突不静默）· 采纳每次 provider mutation 返回的新 etag（rename/move/restore/upload）· 删除=移到 `.trash`（脏字节绝不硬删）· 离线删除队列持久化并重放 · pull 前校验字节（防 captive-portal HTML 覆盖唯一好副本）· 驱逐只动 `clean ∧ 可重取`（脏的先 `.backup`）· ready-gate（含带编辑器 resume）· 加密容器。

---

## 7. store 怎么对 UI 有强制性（Model B）

store **不画像素**（无 DOM、无 `alert/confirm`），但它**驱动整个 flow**，在每个决策点**回调进你注入的 `ui` 并 await**——你不处理，flow 就过不去。这就是强制力：不是 store 替你画对话框，是**没解决就完不成这次写**。

### 必填注入 `ui`（store 在这些时机回调进来）—— **全部必填，禁 placeholder/noop**（缺真 UI 就老实做或 escalate）
```ts
const ui = {
  // 危险写操作的锁屏遮罩：store 把每个写裹进来。你画一个吞输入的全屏遮罩即可。
  busy: <T>(label: string, fn: () => Promise<T>) => Promise<T>,
  // push 撞冲突时 store 调它；返回有限选项之一，后果由 store 执行(见下表)。**必给真 sheet，绝不静默 cancel**。
  resolveConflict: (ctx: { name: string; local: Blob | null; cloud: Blob | null }) => Promise<ConflictChoice>,
  // 非阻断错误(网络/文件不存在/字节非法)：store 调它弹 error banner。**必给，绝不吞 console**。
  //   level 缺省 "error"。分级 "error"|"warning"→banner、"info"→状态栏、"log"→仅 console(良性 offline/fallback)。
  //   深模块不直接持有 ui：它们 import 库内 `error-handling.ts` 的 `reportStoreError(err, level)`，
  //   createStore 装配时把它接到本 `reportError`（store 侧只 funnel、不 console.log，最终消费者才 log）。
  reportError: (err: unknown, level?: "error" | "warning" | "info" | "log") => void,
  // 选填：云检查「跳过到离线」逃生闸（缺它优雅退回 isOnline 守卫，非隐藏失败）。
  offlineEscape?: () => { probe: Promise<unknown>; settle: () => void },
};
```
> **加密密码不走 ui**（无 `askPassword`）：非交互 `crypt.getPassword`（只读内存），解锁循环（prompt→`file.verifyPassword`→存密码→重跑）是 app 在 busy 外自管的事（§5）。

### 冲突的有限选项 + 后果（store 执行，app 只渲染那几个按钮）
| `ConflictChoice` | store 做什么 |
|---|---|
| `"keepMine"` | 备份云端副本到 `.backup` → 用本地快照 weak-override 云端 → 采纳新 etag |
| `"takeCloud"` | 备份本地 → 拉云端覆盖本地缓存 → 采纳云端 etag |
| `"cancel"` | 什么都不动；本地保持脏，下个周期再试 |

### store 编排的两条硬律（Model B 的代价 = 它的卖点）
1. **先退 busy 遮罩、再弹 modal**：store 调 `resolveConflict` 前先退出 busy 遮罩，否则遮罩盖住对话框 = 死锁（前身踩过）。这套交错归 store 管、一次做对。（密码同理：app 的解锁循环也在 busy 外。）
2. **await 期间 push-lock 安全**：flow 卡在回调 await 上时，同文件后续 push 排队、不死锁、不丢。

### 原子性不变量（#76）
flow 的原子单位是「进入 flow 那刻抓的**不可变快照**」，不是 wall-clock。store **永不回写 app 的活动状态**；回调 await 期间 app 的 mutation 归**下一个 dirty 周期**的新快照，绝不塞进正在飞的 flow。（外部如云端 API 的并发不在此保证内。）

### 另外的"形状强制"
- `getPeek` 只在 `ZipFile` 上 → 逼你想清文件是不是 zip。
- `get` 不给 default → 逼你把默认值收一处。
- 密码**非交互**（`crypt.getPassword` 只读内存）→ 逼解锁 UX 收进 app 的 busy 外循环。

**觉得某个 API 不该这样、想绕：停下 escalate to human。** 大概率它那样是为守某条红线。

---

## 8. 禁止 & escalate 速查

| 你想做 | 别这样 | 应该 |
|---|---|---|
| 缓存文件离线读 | 自己开 IndexedDB | `file.open` 自动缓存 |
| 让文件离线常驻 / 腾本地空间 | 自己管 IndexedDB 容量 | `file.keepOffline()` / `file.offload()` |
| 找回删掉的文件 | —— | `store.files.listTrash()` + `store.files.restoreTrash()` |
| 删文件夹 | 自己 provider.delete（递归！） | `store.files.deleteFolder()`（护栏在 backend `deleteEmptyFolder`：只删空夹；离线排队回线 drain） |
| 存设置 / 状态 | 自己 localStorage | 建 `store.collection(...)`（`{local:true}` 设备本地 / 默认 synced，**同名单例**），直读写 KV 面（§4） |
| 列云端文件 | 自己 Graph fetch | `store.files.watchFolder`（订阅当前夹） |
| 加密 | 自己写 zip/7z/容器 | 注入 `crypto` codec（§1）+ `crypt.getPassword` + `file.encrypt/decrypt`，逻辑库管 |
| 局部改 collection 一条 | 找 partial-update API | 取整条 → 改 → `setItem` |
| 库没有你要的操作 | deep import 内部 / 自己实现 | **escalate to human 改库 API** |


## 改这份文档前请读（写给AI coding agent）

这一节Coding Agent不能改。

本文是人类监督 coding agent 的依据：人读它来判断 agent 对这个代码库的改动对不对、代码库当前是什么、interface，接缝和核心承诺是什么。所以它只有一个命根子——**人能读懂**。它一旦混淆（堆细节、堆术语、重心偏移），人就看不住 agent，本文也就废了。混淆主要从两个方向来：

**一、膨胀。** 把刚被关注的细节越写越细，写到它占的篇幅配不上它的分量；几轮下来重心全偏到角落，整体没法读了。

要求：本文结构固定为「铁律 → 心智模型 → 入口 → 分模块 API → 机制」，每部分篇幅与其重要性成比例，维持这一比例是硬约束。
- 改某个 API（增删参数、改返回、改错误）：只改对应方法所在那一节的签名块或表格行。不为单个 API 新开解释段、背景或原理。
- 改概念（新增一类 store、换 provider、改核心同步语义）：才回骨架，重写对应层级。需要向人类escalate。
- 想加的散文只服务一个细节、不服务全文：不加。压成签名块里的一行注释，或归入末尾的机制说明章节（§6 / §7）。


**二、自言自语。** 写出只有读过某段背景的人才懂的话——针对某次对话的解释、某个内部代号、某条临时进度、某个用户随口说的特殊术语。对没有那段背景的读者，这就是噪音。

要求：每句话都须对一个没有任何项目背景的读者成立。检验方法是把任意一句单独拎出来——若它暗示了读者应当已经知道某段背景，重写它。
- 使用方用通用说法（「一个绘画 app」而不是某个项目代号），不用读者未必认得的专名。
- 功能状态写「已实现」或「计划中（未实现）」，以及改动的时间戳（yyyymmdd HH:mm）
- 不写「最重要的一条」「最常见的问题」这种相对当下讨论才成立的说法；分量靠结构和位置体现，不靠强调。

**例行规则：** 本文描述「这个库现在是什么、怎么用」，改动记录属于 `CHANGELOG.md`，不进本文。本 README.md 随引擎一起拷，是唯一权威；与代码冲突时说明代码可能漂移，请escalate to human。改动记录不进本文。