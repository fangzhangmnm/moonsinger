# @internal/workbench-elements

> created 2026-09-09 by Claude Fable 5.1 · as-of 0.3.0（2026-11-11 加浮窗的壳；2026-11-12 加下拉标准件） · 源 = WeebPaint v0.14.9 `src/ui/{popup-menu,notice,icon}.ts` + `src/anchored-popup.ts`（WET，不改语义）

```ts
import { configureFloors, togglePopupMenu, showNotice, iconHtml } from "@internal/workbench-elements";
configureFloors({ toolbarBottom: () => topBar.getBoundingClientRect().bottom });   // 宿主布局知识，一次注入；无顶栏的宿主不用配
```
- CSS：宿主把 `@internal/workbench-elements/workbench-elements.css` 内联进自己的样式（class 名与 WeebPaint 同）。需要宿主 `:root` 提供 `--bg --bg-soft --ink --ink-soft --line --shadow --accent --danger --z-menu --z-popover --z-modal --z-notice --z-toast`。
- 图标：`iconHtml(name)` 只拼 `<svg><use href="#name">`，sprite 由宿主内联（家族图标库 `extract-icons.py`）。
- 收货：在消费方仓根 `bash "../20260909 internal-workbench-elements/scripts/pull-package.sh" <ver>`。

## 浮窗的壳 `float-window`（0.2.0 起）

> added 2026-11-11 by Claude Opus 5.5 · CatsUp 施工单十七 / 家族周账 F-253 第一步。来历：WeebPaint `src/ui/floating-window.ts` + `panel-gizmo.ts` → CatsUp 拷贝 → 这里（搬，不重写，接口名字照旧）。

一扇常驻浮窗的整个一生只在这一处：z 序（点窗 = 置顶）、钳进视口（拖把不进顶边死区、不出屏、不被屏底占掉的那截盖住）、标题栏拖动、右下角改大小、恢复位置、转屏 / 拉窗重钳、临时藏窗。库不存东西、不认识 app：位置 / 大小 / 收没收起都用回调交给宿主。

```ts
import { configureFloatingWindows, registerFloatingWindow } from "@internal/workbench-elements";
configureFloatingWindows({ hudBottom: () => hudRow.getBoundingClientRect().bottom });   // 一次；不配 = host-floors 的 floatingTop()
const win = registerFloatingWindow(el, {
  id: "layers", head: titleBar, onMove: (p) => remember(p),
  resize: { grip: null, min: { w: 200, h: 160 }, onResize: (s) => remember(s) },
  bottomFloor: () => drawerHeight(),                          // 可选：底部抽屉 / 软键盘占掉的高度
  shell: {                                                    // 可选：四样壳零件，全不开 = 没有壳
    knob: { icon: "layers", label: "图层", hint: "点一下收起，按住拖" },   // 左上圆钮（icon = sprite 的 symbol id）：点 = 收起 / 恢复，动过 4 px = 挪窗
    collapsible: { onCollapse: (c) => remember(c), restoreLabel: "打开图层" },   // 收成 44 px 的小图标（要 knob）
    corner: true,                                             // 库画右下 19 px 斜纹角当改大小的把手（要 resize，且 resize.grip = null）
    fade: true,                                               // 2.5 秒不动淡到 0.35；能悬停的设备上离窗全隐
  },
});
win.open(); win.restore({ left: 40, top: 80, width: 320 });
```

- 组合不对就抛、不悄悄挑一个：`corner` 没给 `resize` / `corner` 和 `resize.grip` 都给 / `collapsible` 没有 `knob`。
- 宿主两家的差别是参数：顶边地板量谁（`hudBottom`）；显隐用 `hidden` 属性还是类名（`hiddenClass`，画画仓 = `"hidden"`）；临时藏窗（`spec.transient` + `suppressFloatingForTransient / restoreFloatingAfterTransient`）；只改宽的窗（`resize.axis: "x"`）、自己落地尺寸的窗（`resize.getSize / apply`）。
- 壳零件的样子在 `workbench-elements.css` 的 `.wbe-float-*`（数照 `@internal/reference-window` 0.4.3 起）。窗本身的底色 / 边框 / 圆角 / 显隐归宿主；token `--bg --ink --line`，圆钮底色可另给 `--wbe-float-dot-bg`。宿主自己的小钮（关、菜单）加类名 `wbe-float-part` 就跟着淡；收起时窗里除了圆钮全藏。
- 视口用 `innerHeight` 不用 `visualViewport`（iOS 软键盘只改后者，跟着它钳会抖）；只有给了 `bottomFloor` 的窗跟 `visualViewport` 重钳。宿主布局变了（抽屉开合）可以调 `clampAllFloatingWindows()`。

## 下拉标准件 `select-field`（0.3.0 起）

> added 2026-11-12 by Claude Opus 5.5（MoonSinger小弟）· MoonSinger 施工单 7-T。来历：WeebPaint v0.14.86 `src/ui/select-field.ts`（Claude Fable 5.1，2026-09-02）→ 这里（搬，不改语义、不改接口名字）。

原生 `<select>` 的打开态归浏览器：iPad 弹系统的层（系统字体、夜间白底白字、装不了 SVG 图标）。这一件 = 一颗按钮 + popup-menu 的 compact 弹层。

```ts
import { mountSelectField, createSelectField } from "@internal/workbench-elements";
const f = mountSelectField(button, {                        // 页面里已有的 <button>；现建 = createSelectField({ ...同样的, id?, className? })
  items: () => [{ value: "treble", label: "高音谱号", short: "高", icon: "clef-treble", group: "常用" }, …],
  value: () => state.clef,                                  // 受控：当前值归宿主
  onChange: (v) => setClef(v),
  band: "modal",                                            // 面板 / 弹窗里传 modal（压过面板）；默认 menu
  face: "label",                                            // 钮面：label 全名（默认）/ short 定宽缩写 / icon 只图标（没图标的项退回缩写）
  ariaLabel: "谱号",
});
f.refresh();   // 值在外面改了
f.dispose();
```

- 弹层：`group` 换了插一行组标题（不可点）；当前项打勾；`disabled` 的灰着点不动；上下键 / 回车 / Esc 归 popup-menu。
- 钮面：当前项的图标（有才画）+ 文字 + 右下角小三角；当前值写在 `el.dataset.value`。定宽档的宽 = 这一个下拉自己量的「最宽的缩写 + 自己的内边距」，量不到就用 CSS 的 `--select-fixed-w`（默认 72px）。
- 样式在 `workbench-elements.css` 的 `.select-field*`，只管排版；按钮的皮（底色 / 边框 / 圆角 / 字号）用宿主自己的类。
- 纯函数 `selectMenuItems(items, cur)` = 项 → 弹层的项（测试用、宿主也可以拿去自己开弹层）。

## 页签条 `tab-strip`、面板外壳 `panel-shell`、一项一行 `setting-row`（0.4.0 起）

> 2026-11-12 Claude Opus 5.5（MoonSinger小弟）。MoonSinger 施工单 13-0 / 13-3（user 批的那一次小号）；写歌软件的设置、页面设置、「这首歌」三处共用。
> WeebPaint、CatsUp 改用这几件不在这一刀里，等它们自己的会话碰到再换。

- **页签条** `createTabStrip({ tabs, current, onPick })`：一排平分的格子，图标在上、小字在下，没有边框，选中的一块底色；永远一排（字放不下省略号，全名在 `title` / 读屏名里）；一格点击高度 ≥ 44 px；左右键 / Home / End 挪。只认「哪几页、图标和字、现在哪页、点了告诉宿主」——换页、记住停在哪页归宿主。`set` / `update` 不回调。
- **面板外壳** `openPanelShell({ title, tabs?, content, buttons, closeId?, onButton?, onClose, width?, mount? })`：遮罩 + 卡片（标题 / 页签条 / 能滚的一层 / 底下一排钮）。点遮罩 = 按下和松手都在遮罩上才关；输入法组字时的 Esc 不关；焦点不出壳（Tab 绕圈）；人点页签换页 = 先回顶再告诉宿主。开着的时候不能换标题和钮（换语言 = 宿主关了重开）。库里不带默认文字。滚动层 `scroller` 归壳，`setContent` 只换宿主那一块。关的两条路：人关（`closeId` 钮 / 点遮罩 / Esc）= 先拆掉再回 `onClose` 一次；宿主 `close()` = 拆掉不回调；都能重复调；关了焦点回到打开前那个元素。层级 = 宿主的 `--z-modal`；壳里的下拉宿主传 `band: "modal"`。
- **一项一行** `settingRowHtml({ label | labelHtml, controlHtml?, notes?, belowHtml?, attrs? })` + `wireSettingRows(root)`：名字后面几个小标记（`RowNote`，如「?」这是什么、「©」版权和使用规则；是字不是图标），点一个 = 这一行下面展开那一段，同一行一次只开一段。两个标记并排时各自的点击区不互相盖。`attrs` 是名字 → 值的表（值库转义，名字只许字母数字和 -）。

**库收到的字符串（全库一条规矩，0.4.0 起）：成员名不以 `Html` 结尾 = 纯文字，库转义；以 `Html` 结尾（还有 `RowNote.html`）= HTML，宿主负责转义。**

**面板外壳和库里已有几件怎么配合**（壳自己做什么、留给宿主什么）：

| 那一件 | 壳开 / 关的时候 | 谁做 |
|---|---|---|
| 下拉 / 弹出菜单（select-field / popup-menu） | 壳里开着的下拉先收 Esc（它在 document 捕获阶段 preventDefault）→ 壳看到 `defaultPrevented` 不关；再按一下才关壳。点遮罩同理：下拉收了那一击（记在 `outside-tap.ts`）→ 壳不关 | 壳（库里两件自己对好；测试 `elements-0.4.test.mjs`、`popup-menu.test.mjs`） |
| 下拉的层级 | 壳在 `--z-modal`，里面的下拉要 `band: "modal"` 才盖得住壳 | 宿主（建下拉时传） |
| 开壳之前已经开着的菜单 | 壳不关别人的弹层 | 宿主 |
| 提示条（notice） | 壳不碰；要不要重排归宿主 | 宿主 |
| 浮窗（float-window） | 壳不藏；要临时藏（`suppressFloatingForTransient`）归宿主 | 宿主 |
| 键盘 | 壳只在自己的根上听（不挂 document / window） | 壳 |
