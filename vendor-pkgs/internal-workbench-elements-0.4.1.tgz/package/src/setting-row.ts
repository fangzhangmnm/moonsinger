// 一项一行 + 小标记展开（第九件，0.4.0）——设置那种：左边名字（名字后面跟几个小标记「?」「©」）、右边控件；点一个小标记 = 这一行下面展开那一段，再点收。
// created 2026-11-12 by Claude Opus 5.5（MoonSinger小弟；MoonSinger 施工单 13-3 / 13 补：「?」= 这是什么，「©」= 版权和使用规则，user 2026-11-12「问号那么小的字的注释上标」）。
// 来历：写歌软件 `src/app/main.ts setItem` + `wireSetPages` 里的「?」那一段。**这一件是以后唯一的一份**（统筹 2026-11-12）：写歌软件混音台的参数行
//   （`src/keyboard/param-row.ts`）也有一个小问号，那一份这次不动，下一次碰它时改用这一件；出现第三份之前必须收。
// 拼字符串（同库里 iconHtml 的写法）；在根上挂一次 wireSettingRows 接点击。
// 转义：**成员名不以 Html 结尾 = 纯文字，库转义；以 Html 结尾 = HTML，宿主负责**（库里统一的规矩，0.4.0 写歌软件统筹审定；理由：名字会是从 user 的 .sf2 里读出来的外来字）。

export interface RowNote {
  /** 名字后面那个小标记上的字（纯文字，如 "?"、"©"；是字不是图标）。 */
  mark: string;
  /** 读屏 / 悬停的全名（纯文字，如「这是什么」「版权和使用规则」）。 */
  label: string;
  /** 点开后这一行下面展开的那一段（HTML，宿主负责转义）。 */
  html: string;
}
export interface SettingRowOpts {
  /** 左边名字（纯文字，库转义）。和 labelHtml 二选一。 */
  label?: string;
  /** 左边名字要带标记时用这个（HTML，宿主负责转义）。 */
  labelHtml?: string;
  /** 右边控件（HTML：下拉、钮…）；不给 = 没有。 */
  controlHtml?: string;
  /** 名字后面的小标记，按给的顺序；一个都没有 = 不画。同一行一次只展开一段。 */
  notes?: readonly RowNote[];
  /** 这一行下面常驻的一块（HTML：列表、状态行…）。 */
  belowHtml?: string;
  /** 宿主自己的属性，名字 → 值（值库转义；名字只许字母、数字和 -、不许以 on 开头（事件属性），不合 = 抛错）。拼在这一行的根上。 */
  attrs?: Readonly<Record<string, string>>;
}

const esc = (s: string): string => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
const attrsHtml = (a: Readonly<Record<string, string>> | undefined): string => Object.entries(a ?? {}).map(([k, v]) => {
  if (!/^[A-Za-z0-9-]+$/.test(k)) throw new Error(`setting-row: bad attribute name ${JSON.stringify(k)}`);
  if (/^on/i.test(k)) throw new Error(`setting-row: event-handler attribute not allowed: ${JSON.stringify(k)}`);   // onclick 这一类会把值当脚本跑：值是外来的字时转义救不了
  return ` ${k}="${esc(v)}"`;
}).join("");

/** 一行的 HTML：`<div class="wbe-row">`（头 = 名字 + 小标记 + 控件；下面是各段说明（收着）和常驻的那一块）。 */
export function settingRowHtml(o: SettingRowOpts): string {
  const notes = o.notes ?? [];
  const marks = notes.map((n, k) => `<button type="button" class="wbe-row-mark" data-note="${k}" aria-expanded="false" aria-label="${esc(n.label)}" title="${esc(n.label)}">${esc(n.mark)}</button>`).join("");
  const label = o.labelHtml ?? esc(o.label ?? "");
  return `<div class="wbe-row"${attrsHtml(o.attrs)}><div class="wbe-row-head"><span class="wbe-row-label">${label}${marks}</span>${o.controlHtml ? `<span class="wbe-row-ctl">${o.controlHtml}</span>` : ""}</div>` +
    notes.map((n, k) => `<div class="wbe-row-note" data-note="${k}" hidden>${n.html}</div>`).join("") + (o.belowHtml ?? "") + `</div>`;
}

/** 在根上挂一次：点某一行的小标记 = 这一行下面展开那一段（同一行别的段收起），再点收。回一个解绑。 */
export function wireSettingRows(root: HTMLElement): () => void {
  const onClick = (e: Event): void => {
    const m = (e.target as HTMLElement | null)?.closest?.<HTMLElement>(".wbe-row-mark"); if (!m || !root.contains(m)) return;
    const row = m.closest<HTMLElement>(".wbe-row"); if (!row) return;
    const k = m.dataset.note, opening = m.getAttribute("aria-expanded") !== "true";
    const mine = (sel: string) => [...row.querySelectorAll<HTMLElement>(sel)].filter((x) => x.closest(".wbe-row") === row);   // 只管这一行自己的（行里再套行时不碰里面那行）
    for (const x of mine(".wbe-row-mark")) x.setAttribute("aria-expanded", String(opening && x.dataset.note === k));
    for (const x of mine(".wbe-row-note")) x.hidden = !(opening && x.dataset.note === k);
  };
  root.addEventListener("click", onClick);
  return () => root.removeEventListener("click", onClick);
}
