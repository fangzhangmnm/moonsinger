// 面板外壳（第八件，0.4.0）——往里面填东西的那层壳：遮罩、卡片、标题、（可选）页签条、能滚的一层、底下一排钮、怎么关。
// created 2026-11-12 by Claude Opus 5.5（MoonSinger小弟；MoonSinger 施工单 13-3，user 2026-11-12「要新做一张面板：正好用共享库」；统筹判的放这一个库）。
// 写歌软件里三处用：设置、页面设置、这首歌。内容、盖层登记、修改锁、记住停在哪页 = 宿主的事；壳不认识里面装的是什么。
//
// 规矩（统筹 2026-11-12 审接口时定的，写死在这里）：
//   · 库里不带任何给人看的默认文字：标题、底下每颗钮上的字都由宿主给。
//   · 键盘只在壳自己的根上听（不挂 document / window）：Esc = 人关。库里的下拉（select-field / popup-menu）在壳里开着时，
//     它在 document 的捕获阶段先收到 Esc、关掉自己并 preventDefault——壳看到 defaultPrevented 就不关（同一个库里两件自己对好；守卫 test/panel-shell.test.mjs）。
//   · 能滚的那一层（scroller）归壳：宿主换内容只换自己交进来的那一块（setContent），滚动层不被换掉 = 调一项页面停在原地。
//   · 关的两条路写死：人关（底下那颗 closeId 钮 / 点遮罩 / Esc）= 壳先拆掉自己、再回 onClose 一次；宿主关 close() = 拆掉、不回调。两条都能重复调。
//     关了之后焦点回到打开之前的那个元素（还在页面上的话；宿主可以再挪）。
//   · 点遮罩关 = 按下和松手都在遮罩上（卡片里按下、拖到遮罩松手不算）；壳里开着下拉时点遮罩 = 只收下拉（下拉记下了这一击，outside-tap.ts）。
//   · 输入法组字时的 Esc（isComposing / keyCode 229）不关。壳的 Esc、页签条的左右 / Home / End 处理过就 stopPropagation（不往外冒）。
//   · 焦点不出壳：Tab / Shift+Tab 在卡片里可聚焦的东西之间绕圈（藏着的、灰着的跳过）。
//   · 人点页签换页 = 壳先把滚动层回顶、再回调宿主；宿主自己 tabs.set / setContent 不动滚动。
//   · 层级：壳在宿主的 --z-modal（CSS .wbe-panel）；壳里开的下拉宿主要传 band: "modal"（popup-menu 的 band 表）。
//   · 转义：title、钮上的字 = 纯文字（库用 textContent 写）；content 是宿主建好的节点（里面的 HTML 宿主自己负责）。
// 和库里已有几件怎么配合（壳自己做什么、留给宿主什么）：
//   · 提示条（notice）：壳不碰。提示条的层级本来在 --z-notice（宿主的 band 表里它在 modal 上面还是下面由宿主定），要不要重排归宿主。
//   · 浮窗（float-window）：壳不藏浮窗。要临时藏起来（suppressFloatingForTransient）归宿主。
//   · 弹出菜单 / 下拉（popup-menu / select-field）：壳不关别人的弹层；开壳之前要不要先关菜单归宿主（多半已经关了）。Esc 的配合见上。
import { createTabStrip, type TabStrip, type TabStripOpts } from "./tab-strip.ts";
import { wasOutsideTap } from "./outside-tap.ts";

export interface PanelButton {
  id: string;
  /** 钮上的字（纯文字；库不带默认的「好」「关」）。 */
  label: string;
  primary?: boolean;
  danger?: boolean;
}
export interface PanelShellOpts<Tab extends string = string> {
  /** 标题（纯文字）。也是对话框的读屏名。 */
  title: string;
  /** 有 = 标题下面一条页签条（第七件）；换页时宿主自己换 content，壳不管。 */
  tabs?: TabStripOpts<Tab>;
  /** 宿主交进来的内容（放进壳的滚动层里）。 */
  content: HTMLElement;
  /** 底下一排钮（从左到右）。至少一颗；库不带默认的钮。 */
  buttons: readonly PanelButton[];
  /** 底下哪一颗 = 人关（点了 = 壳拆掉自己、回 onClose）；其余的点了回 onButton。不给 = 底下没有关的钮（遮罩 / Esc 照样能关）。 */
  closeId?: string;
  /** 点了底下 closeId 以外的钮。 */
  onButton?(id: string): void;
  /** 人关了（closeId 钮 / 点遮罩 / Esc）：壳已经拆掉了，回这一次。宿主在这里销掉自己的盖层登记等。 */
  onClose(): void;
  /** 卡片多宽：narrow ≈ 360 px（问一句的那种），wide = 设置那种。默认 narrow。 */
  width?: "narrow" | "wide";
  /** 挂在哪个节点下；默认 document.body。 */
  mount?: HTMLElement;
}
export interface PanelShell<Tab extends string = string> {
  /** 整层（遮罩 + 卡片）：`<div class="wbe-panel">`。 */
  readonly el: HTMLElement;
  /** 壳的滚动层（`.wbe-panel-scroll`）：一直是这一个节点，换内容不换它。 */
  readonly scroller: HTMLElement;
  /** 宿主交进来的那一块（现在的）。 */
  readonly content: HTMLElement;
  /** 页签条（opts.tabs 给了才有）。 */
  readonly tabs: TabStrip<Tab> | null;
  readonly isOpen: boolean;
  /** 换掉宿主那一块（滚动层不换，滚到哪儿留着——浏览器按新内容的高度收一下）。 */
  setContent(next: HTMLElement): void;
  /** 宿主关：拆掉、不回 onClose；能重复调。 */
  close(): void;
}

export function openPanelShell<Tab extends string>(opts: PanelShellOpts<Tab>): PanelShell<Tab> {
  const before = (typeof document !== "undefined" ? document.activeElement : null) as HTMLElement | null;
  const el = document.createElement("div");
  el.className = "wbe-panel";
  const card = document.createElement("div");
  card.className = `wbe-panel-card wbe-panel-card--${opts.width ?? "narrow"}`;
  card.setAttribute("role", "dialog"); card.setAttribute("aria-modal", "true"); card.setAttribute("aria-label", opts.title); card.setAttribute("tabindex", "-1");
  const head = document.createElement("div"); head.className = "wbe-panel-title"; head.textContent = opts.title; card.appendChild(head);
  const scroller = document.createElement("div"); scroller.className = "wbe-panel-scroll";
  const hostTabs = opts.tabs;
  const tabs = hostTabs ? createTabStrip<Tab>({ ...hostTabs, onPick: (id) => { scroller.scrollTop = 0; hostTabs.onPick(id); } }) : null;   // 人换页 = 先回顶再告诉宿主
  if (tabs) card.appendChild(tabs.el);
  card.appendChild(scroller);
  let content = opts.content; scroller.appendChild(content);
  const foot = document.createElement("div"); foot.className = "wbe-panel-btns";
  for (const b of opts.buttons) {
    const x = document.createElement("button"); x.type = "button"; x.dataset.panelBtn = b.id;
    x.className = "wbe-panel-btn" + (b.primary ? " primary" : "") + (b.danger ? " danger" : ""); x.textContent = b.label;
    foot.appendChild(x);
  }
  card.appendChild(foot);
  el.appendChild(card);

  let open = true, downOnBackdrop = false;
  const teardown = (): boolean => {
    if (!open) return false;
    open = false;
    el.removeEventListener("pointerdown", onDown); el.removeEventListener("click", onClick); el.removeEventListener("keydown", onKey as EventListener);
    tabs?.dispose(); el.remove();
    try { if (before && before.isConnected) before.focus(); } catch { /* 焦点还不回去就算了 */ }
    return true;
  };
  const humanClose = (): void => { if (teardown()) opts.onClose(); };
  /** 这一下按在遮罩上（卡片外面），并且不是下拉收走的那一击。 */
  const onDown = (e: Event): void => { downOnBackdrop = e.target === el && !wasOutsideTap(e); };
  const onClick = (e: Event): void => {
    const t = e.target as HTMLElement | null, wasDown = downOnBackdrop; downOnBackdrop = false;
    if (t === el) { if (wasDown) humanClose(); return; }   // 点遮罩：按下和松手都在遮罩上才算（卡片里按下、拖出来松手 = click 落在共同的祖先上，不算）
    const b = t?.closest?.<HTMLElement>("[data-panel-btn]"); if (!b || !foot.contains(b)) return;
    const id = b.dataset.panelBtn!;
    if (id === opts.closeId) humanClose(); else opts.onButton?.(id);
  };
  /** 卡片里能用 Tab 走到的东西（按文档顺序；藏着的子树、灰着的跳过）。 */
  const focusables = (): HTMLElement[] => {
    const out: HTMLElement[] = [];
    const walk = (n: Element): void => {
      for (const c of Array.from(n.children) as HTMLElement[]) {
        if (c.hidden) continue;
        const tag = c.tagName, ti = c.getAttribute("tabindex");
        const can = ti !== null ? ti !== "-1" : tag === "BUTTON" || tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA" || (tag === "A" && c.getAttribute("href") !== null);
        if (can && !(c as HTMLButtonElement).disabled) out.push(c);
        walk(c);
      }
    };
    walk(card);
    return out;
  };
  const onKey = (e: KeyboardEvent): void => {
    if (e.key === "Tab") {   // 焦点不出壳：两头绕圈；中间的照浏览器的来
      const f = focusables(); if (!f.length) { e.preventDefault(); return; }
      const at = document.activeElement, first = f[0]!, last = f[f.length - 1]!;
      if (e.shiftKey && (at === first || !card.contains(at))) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && (at === last || !card.contains(at))) { e.preventDefault(); first.focus(); }
      return;
    }
    if (e.key !== "Escape" || e.defaultPrevented) return;   // 壳里开着的下拉先收了这一下（它 preventDefault）= 壳不关
    if (e.isComposing || e.keyCode === 229) return;   // 输入法组字时的 Esc 是给输入法的
    e.preventDefault(); e.stopPropagation(); humanClose();
  };
  el.addEventListener("pointerdown", onDown);
  el.addEventListener("click", onClick);
  el.addEventListener("keydown", onKey as EventListener);
  (opts.mount ?? document.body).appendChild(el);
  try { card.focus(); } catch { /* 没有焦点也照样能用 */ }

  return {
    el, scroller, tabs,
    get content() { return content; },
    get isOpen() { return open; },
    setContent(next) { if (next === content) return; scroller.replaceChild(next, content); content = next; },
    close() { teardown(); },
  };
}
