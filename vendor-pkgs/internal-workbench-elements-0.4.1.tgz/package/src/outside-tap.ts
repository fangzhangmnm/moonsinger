// 弹出菜单（下拉）收了的那一击（库内部，不出门牌）。created 2026-11-12 by Claude Opus 5.5（MoonSinger小弟；写歌软件统筹审 0.4.0 第 3 处）。
// 弹出菜单在 document 捕获阶段收到「点在外面」的 pointerdown、关掉自己时记下这个事件；面板外壳看到它就不把这一击当成「点遮罩」——
//   壳里开着下拉时点遮罩 = 只收下拉、壳不关（下拉默认不吞那一击：swallowOutsideTap 默认关，原有的行为不动）。
const taken = new WeakSet<object>();
/** 弹出菜单：这一击我收了（关掉了自己）。 */
export function noteOutsideTap(e: Event | object): void { taken.add(e); }
/** 这一击是不是已经被哪个弹出菜单收了。 */
export function wasOutsideTap(e: Event | object): boolean { return taken.has(e); }
