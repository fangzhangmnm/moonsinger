// 页签条（第七件，0.4.0）——一排平分的格子：图标在上、小字在下，没有边框，选中的那一格一块底色；永远一排，字放不下 = 省略号（全名在 title / 读屏名里）。
// created 2026-11-12 by Claude Opus 5.5（MoonSinger小弟；MoonSinger 施工单 13-0，user 2026-11-12「设置的页签换成 WeebPaint 和 CatsUp 那种…同意把它抽进界面零件库」）。
// 来历：WeebPaint `styles.css .menu-tabs / .menu-tab`（☰ 面板）和 CatsUp `src/app/ui/popup-menu.ts`（抄 WeebPaint）共同的那一件；两家都焊在弹出菜单里，这里单独成一件。
// 零内容知识：只认「哪几页、各自的图标和字、现在是哪一页、点了告诉宿主」。换页、记住上次停在哪页 = 宿主的事。不带徽标 / 禁用格（现在没人要）。
// 键盘：页签上左右键挪到旁边一格、Home / End 到头尾（标准的 tablist 行为），挪了 = onPick。
// 一格的点击高度不低于 44 px（CSS .wbe-tab min-height）。一格的字宜 ≤ 3 个汉字 / 6 个字母（写歌软件统筹 2026-11-12 的规矩：超过 6 页先并页或拆面板，不靠折行 / 横滚）。
import { iconHtml, type IconName } from "./icon.ts";

export interface TabSpec<Id extends string = string> {
  id: Id;
  /** 一格里的短名字（纯文字，库用 textContent 写，不当 HTML）。放不下 = 省略号。 */
  label: string;
  /** 宿主 sprite 里的图标 id；不给 = 只有字。 */
  icon?: IconName;
  /** 全名（纯文字）：悬停提示 + 读屏名；不给 = label。 */
  title?: string;
}
export interface TabStripOpts<Id extends string = string> {
  tabs: readonly TabSpec<Id>[];
  current: Id;
  /** 人点了一格（或用左右键挪到）= 告诉宿主；库先把那一格亮起来再回调。点已经亮着的那一格不回调。 */
  onPick(id: Id): void;
}
export interface TabStrip<Id extends string = string> {
  /** `<div class="wbe-tabs" role="tablist">`：宿主放到哪里由宿主定（面板外壳会放在标题下面）。 */
  readonly el: HTMLElement;
  /** 宿主换了页（比如从别处跳进来）= 亮那一格；不回调 onPick。 */
  set(id: Id): void;
  /** 页变了（多一页 / 少一页 / 换了界面语言）：整排重画；current 不给 = 留在原来那一页（不在了 = 第一页）。不回调。 */
  update(tabs: readonly TabSpec<Id>[], current?: Id): void;
  /** 拆掉监听、从页面上拿掉。 */
  dispose(): void;
}

export function createTabStrip<Id extends string>(opts: TabStripOpts<Id>): TabStrip<Id> {
  let tabs = [...opts.tabs], cur: Id = opts.current;
  const el = document.createElement("div");
  el.className = "wbe-tabs"; el.setAttribute("role", "tablist");
  let btns: HTMLButtonElement[] = [];   // 现在的那几格（按 tabs 的顺序）
  const paint = (): void => {
    for (const b of btns) { const on = b.dataset.tab === cur; b.setAttribute("aria-selected", String(on)); b.setAttribute("tabindex", on ? "0" : "-1"); b.classList.toggle("on", on); }
  };
  const build = (): void => {
    for (const b of btns) b.remove();
    btns = [];
    for (const t of tabs) {
      const b = document.createElement("button");
      b.type = "button"; b.className = "wbe-tab"; b.setAttribute("role", "tab"); b.dataset.tab = t.id;
      const full = t.title ?? t.label; b.setAttribute("title", full); b.setAttribute("aria-label", full);
      if (t.icon) { const i = document.createElement("span"); i.className = "wbe-tab-icon"; i.innerHTML = iconHtml(t.icon); b.appendChild(i); }
      const s = document.createElement("span"); s.className = "wbe-tab-label"; s.textContent = t.label; b.appendChild(s);
      el.appendChild(b); btns.push(b);
    }
    paint();
  };
  const pick = (id: Id, focus: boolean): void => {
    if (id === cur) return;
    cur = id; paint();
    if (focus) btns.find((b) => b.dataset.tab === id)?.focus();
    opts.onPick(id);
  };
  const onClick = (e: Event): void => {
    const t = e.target as Node | null, b = btns.find((x) => x === t || x.contains(t)); if (!b) return;
    pick(b.dataset.tab as Id, false);
  };
  const onKey = (e: KeyboardEvent): void => {
    const i = tabs.findIndex((t) => t.id === cur); if (i < 0 || !tabs.length) return;
    const j = e.key === "ArrowRight" ? (i + 1) % tabs.length : e.key === "ArrowLeft" ? (i - 1 + tabs.length) % tabs.length : e.key === "Home" ? 0 : e.key === "End" ? tabs.length - 1 : -1;
    if (j < 0) return;
    e.preventDefault(); e.stopPropagation(); pick(tabs[j]!.id, true);   // 处理过的键不往外冒（外面的谱 / 键盘总闸不该再收到它）
  };
  el.addEventListener("click", onClick);
  el.addEventListener("keydown", onKey as EventListener);
  build();
  return {
    el,
    set(id) { if (tabs.some((t) => t.id === id)) { cur = id; paint(); } },
    update(next, current) { tabs = [...next]; const want = current ?? cur; cur = tabs.some((t) => t.id === want) ? want : (tabs[0]?.id ?? want); build(); },
    dispose() { el.removeEventListener("click", onClick); el.removeEventListener("keydown", onKey as EventListener); el.remove(); },
  };
}
