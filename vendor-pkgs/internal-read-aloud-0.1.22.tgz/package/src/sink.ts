// 喇叭：Web Audio 版（把一段 PCM 播出来）。created 2026-10-01 by Claude Fable 5.1
//
// iOS / Safari 的规矩：AudioContext 必须在用户手势里创建或恢复。合成是异步的，等声音算好再建就晚了——
// 所以宿主要在点击处理函数里**同步**调一次 unlock()，之后 play 随时可以。
// **任何时刻只有一段在响**：play 进来先停上一段（控制器也守着同一条，这里是第二层）。
// 这是「亮屏朗读」的喇叭：屏幕锁了、页面进后台，浏览器会把 AudioContext 挂起（锁屏连读不在这一版的承诺里）。
import type { AudioSink, Clip, Playback } from "./read-aloud.ts";

export interface WebAudioSink extends AudioSink {
  /** 在用户手势里同步调用：建 / 恢复 AudioContext。重复调用无害。 */
  unlock(): void;
  /** 放掉 AudioContext（宿主退出朗读时调；之后再 unlock 会重建）。 */
  close(): void;
}

/** 「该播完了」之后再等这么久还没收到 ended 通知，就自己收场（秒）。 */
const END_SLACK_S = 0.4;

export function createWebAudioSink(): WebAudioSink {
  let ctx: AudioContext | null = null;
  let current: Playback | null = null;   // 正在响的那一段：喇叭自己保证任何时刻只有一段（上层再怎么出错也叠不起来）
  const ensure = (): AudioContext => {
    if (!ctx || ctx.state === "closed") {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    return ctx;
  };
  return {
    unlock() { const c = ensure(); if (c.state === "suspended") void c.resume().catch(() => { /* 不在手势里：下次手势再试 */ }); },
    close() { if (current) { const prev = current; current = null; prev.stop(); } const c = ctx; ctx = null; if (c && c.state !== "closed") void c.close().catch(() => { /* ignore */ }); },
    play(clip: Clip): Playback {
      if (current) { const prev = current; current = null; prev.stop(); }   // 新的一段进来：先掐掉上一段（新点的优先）
      const c = ensure();
      const buf = c.createBuffer(1, clip.samples.length, clip.sampleRate);
      buf.copyToChannel(clip.samples as Float32Array<ArrayBuffer>, 0);
      const src = c.createBufferSource();
      src.buffer = buf; src.connect(c.destination);
      let settle: (ok: boolean) => void = () => {};
      let settled = false;
      const done = new Promise<boolean>((r) => { settle = (ok) => { if (!settled) { settled = true; r(ok); } }; });
      const pb: Playback = {
        done,
        stop() { if (current === pb) current = null; settle(false); try { src.onended = null; src.stop(); src.disconnect(); } catch { /* 已经停了 */ } },
        pause() { void c.suspend().catch(() => { /* ignore */ }); },
        resume() { void c.resume().catch(() => { /* ignore */ }); },
      };
      const finish = () => { if (current === pb) current = null; settle(true); };
      src.onended = finish;
      if (c.state === "suspended") void c.resume().catch(() => { /* ignore */ });
      src.start();
      current = pb;
      // 保险：等不到 ended 也要收场。2026-10-01 在无头 Chromium 里见过——声卡时钟在一段刚播完的那一刻停住不走了（状态仍是 running），
      // 浏览器就一直不发 ended，朗读卡在这一句上。所以按墙上的钟自己数：只在声卡处于 running 时累计（暂停 / 还没解锁不算），
      // 累计过了「这段的长度 + 余量」还没等到通知，就当它播完。正常情况下 ended 先到，这里什么都不做。
      let ran = 0, last = performance.now();
      const watch = setInterval(() => {
        const now = performance.now();
        if (settled) { clearInterval(watch); return; }
        if (c.state === "running") ran += now - last;
        last = now;
        if (c.state === "closed" || ran >= (buf.duration + END_SLACK_S) * 1000) {
          clearInterval(watch);
          try { src.onended = null; src.stop(); src.disconnect(); } catch { /* 已经停了 */ }   // 声卡要是后来又走起来，这一段不许拖着尾巴和下一段叠在一起
          finish();
        }
      }, 100);
      return pb;
    },
  };
}
