// 牌组模型：参考窗里那一叠卡。零 DOM——node 直测；CatsUp 的 VR 视图、宿主自己重写的视图也从这里进。
// created 2026-09-29 by Claude Fable 5.1
// 契约出处 = 家族根 ai-docs/20260929-reference-window-tech-plan.md §3。
//
// 三条规矩：
//   1. 本模块不持久化、不联网、不碰 DOM。宿主用 snapshot() 把牌组拿走，写进自己的容器。
//   2. restore() 是载入恢复专用，静默；其余一切变更都通知 onChange（宿主据此同步清单、决定标不标脏）。
//   3. 这个宿主不认识的卡不进 cards（画不出来），但原样留在 carried 里，保存时原样写回。

/** 每张卡自己的视图状态。图片：平移 / 缩放 / 旋转。文字：scale = 字号倍率，ty = 滚动位置。 */
export interface CardView { tx: number; ty: number; scale: number; rot: number }
/** 音视频的播放位置。fps（0.5.0，视频卡）= 量到 / 宿主给的帧率，逐帧后退按它算一帧多长；没有 = 还没量到（第一次「下一帧」会播到下一帧再停，顺手量出来）。 */
export interface CardPlay { t: number; loop: boolean; fps?: number }

/** 卡片种类是开放集。库自带的种类名见各 kinds 入口；宿主可以登记自己的。 */
export type CardKind = string;

export interface Card {
  /** 牌组内不透明 id。不持久化：每次 restore / add 重新发。 */
  readonly id: string;
  kind: CardKind;
  /** 文件名或首行。 */
  name: string;
  /** 字节，总是随文档保存。null 只出现在零字节的卡（如 "live"）或文件损坏缺字节时。 */
  bytes: Blob | null;
  mime: string;
  /** 宿主自己解析的不透明引用（"live" 卡：哪块画布 / 哪台相机）。库不解释。 */
  target: string | null;
  vp: CardView | null;
  play: CardPlay | null;
  /** 来历标记，平铺不套层。目前只有 "genai"。 */
  origin: string | null;
  /** 0.4.0「只放内存」（RAM only）：字节不随文档保存，只记原文件多大；下次打开是一个空位，提示重新导入、补回原位。null = 照常存。
   *  2026-10-09 user「然后能不能加RAM only，就是不落盘，每次重新上传，这个非常有用！！！」→ 选了「B」（存一个空位）——翻掉 2026-09-29 去掉「只在这次有效」的决定。 */
  ram: { bytes: number } | null;
  /** 0.5.0 清单纪律（家族根 ai-docs/20261021-format-version-discipline.md §3「直通」）：清单条目里本库不认识的键（更新版本的库写的、或宿主自己塞的）
   *  原样带着、保存时原样写回；已知键永远赢。null = 没有。 */
  extra: Record<string, unknown> | null;
}

/** 新卡：只有 kind 必填，其余缺省为空。 */
export type NewCard = { kind: CardKind } & Partial<Omit<Card, "id" | "kind">>;

/** 这个宿主不认识的卡：清单条目和它引用的字节原样带着。 */
export interface CarriedItem {
  /** 它在清单里原来排第几张（写回时尽量放回原位）。 */
  at: number;
  /** 清单条目原文（JSON）。 */
  item: Record<string, unknown>;
  /** 条目引用的字节（按清单里的 src）。 */
  files: { src?: Blob };
}

export interface DeckSnapshot {
  index: number;
  cards: Card[];
  carried: CarriedItem[];
  /** 0.5.0：清单顶层本库不认识的键（更新版本的库写的），原样带着、保存时原样写回。没有 = {}。 */
  extra: Record<string, unknown>;
}
/** restore 的入参：卡可以不带 id（载入时本来就没有）。 */
export interface DeckRestore {
  index?: number;
  cards: readonly NewCard[];
  carried?: readonly CarriedItem[];
  extra?: Record<string, unknown>;
}

export type DeckChange =
  /** 增 / 删 / 挪：牌组内容变了，宿主应标脏。 */
  | { type: "cards" }
  /** 翻页 / 平移缩放 / 滚动 / 播放位置：只是看法变了。标不标脏归宿主。 */
  | { type: "view" }
  /** "live" 卡：宿主报「内容变了」，何时真去要一帧由视图定。 */
  | { type: "invalidate"; id: string }
  /** restore / clear 之后整副牌换了：视图该整个重画。不是用户改动，宿主不应据此标脏。 */
  | { type: "reset" };

export interface Deck {
  readonly size: number;
  readonly index: number;
  readonly current: Card | null;
  cards(): readonly Card[];
  get(id: string): Card | null;
  indexOf(id: string): number;
  snapshot(): DeckSnapshot;
  /** 载入恢复专用：整副换掉。返回新发的 id（顺序 = cards 顺序）。只发 "reset"。 */
  restore(s: DeckRestore): string[];
  /** 清空（换文档 / 重置）。只发 "reset"。 */
  clear(): void;
  /** 加一张卡。select 缺省 true = 加完翻到它。 */
  add(card: NewCard, opts?: { select?: boolean }): string;
  remove(id: string): void;
  /** 挪到第 toIndex 张（越界自动钳）。当前看的那张卡跟着走，不会因为挪动而换成别的卡。 */
  move(id: string, toIndex: number): void;
  select(index: number): void;
  setView(id: string, vp: CardView): void;
  setPlay(id: string, play: CardPlay): void;
  /** 改链接卡指向谁（宿主的页改了名）。内容变了 → 通知 "cards"；视图该重取内容。 */
  setTarget(id: string, target: string | null): void;
  /** 0.4.0：这张卡「只放内存」开 / 关。存不存变了 → 通知 "cards"（宿主标脏）。关掉要求手上有字节（空位关不了）。 */
  setRam(id: string, on: boolean): void;
  /** 0.4.0：给「只放内存」的空位补回字节（重新导入）。存的东西没变（这种卡本来就不存字节）→ 通知 "view"。 */
  fill(id: string, bytes: Blob, mime?: string): void;
  invalidate(id: string): void;
  onChange(fn: (what: DeckChange) => void): () => void;
}

function cloneView(v: CardView | null | undefined): CardView | null {
  if (!v) return null;
  const ok = Number.isFinite(v.tx) && Number.isFinite(v.ty) && Number.isFinite(v.scale) && Number.isFinite(v.rot);
  return ok ? { tx: v.tx, ty: v.ty, scale: v.scale, rot: v.rot } : null;
}
function clonePlay(p: CardPlay | null | undefined): CardPlay | null {
  if (!p || !Number.isFinite(p.t)) return null;
  const fps = typeof p.fps === "number" && Number.isFinite(p.fps) && p.fps > 0 ? p.fps : undefined;
  return fps !== undefined ? { t: p.t, loop: !!p.loop, fps } : { t: p.t, loop: !!p.loop };
}
function cloneExtra(x: Record<string, unknown> | null | undefined): Record<string, unknown> | null {
  if (!x || typeof x !== "object" || Array.isArray(x) || Object.keys(x).length === 0) return null;
  return JSON.parse(JSON.stringify(x)) as Record<string, unknown>;
}
function cloneCarried(c: CarriedItem): CarriedItem {
  return { at: c.at, item: JSON.parse(JSON.stringify(c.item)) as Record<string, unknown>, files: { ...c.files } };
}
function clampIndex(i: number, n: number): number {
  if (n <= 0) return 0;
  if (!Number.isFinite(i)) return 0;
  return Math.max(0, Math.min(n - 1, Math.trunc(i)));
}

export function createDeck(): Deck {
  let cards: Card[] = [];
  let carried: CarriedItem[] = [];
  let extra: Record<string, unknown> = {};
  let index = 0;
  let seq = 0;
  const listeners = new Set<(what: DeckChange) => void>();

  const emit = (what: DeckChange): void => {
    // 逐个调；一个监听者抛错不许拖垮别的监听者，也不许吞掉——收集后统一重抛第一个。
    let first: unknown = null, threw = false;
    for (const fn of [...listeners]) {
      try { fn(what); } catch (e) { if (!threw) { threw = true; first = e; } }
    }
    if (threw) throw first;
  };
  const make = (c: NewCard): Card => ({
    id: `c${++seq}`,
    kind: c.kind,
    name: c.name ?? "",
    bytes: c.bytes ?? null,
    mime: c.mime ?? (c.bytes?.type || ""),
    target: c.target ?? null,
    vp: cloneView(c.vp),
    play: clonePlay(c.play),
    origin: c.origin ?? null,
    ram: c.ram && Number.isFinite(c.ram.bytes) ? { bytes: c.ram.bytes } : null,
    extra: cloneExtra(c.extra),
  });
  const copy = (c: Card): Card => ({ ...c, vp: cloneView(c.vp), play: clonePlay(c.play), ram: c.ram ? { bytes: c.ram.bytes } : null, extra: cloneExtra(c.extra) });

  const deck: Deck = {
    get size() { return cards.length; },
    get index() { return index; },
    get current() { return cards[index] ?? null; },
    cards: () => cards,
    get: (id) => cards.find((c) => c.id === id) ?? null,
    indexOf: (id) => cards.findIndex((c) => c.id === id),

    snapshot: () => ({ index, cards: cards.map(copy), carried: carried.map(cloneCarried), extra: cloneExtra(extra) ?? {} }),

    restore(s) {
      if (!s || !Array.isArray(s.cards)) throw new TypeError("Deck.restore expects { cards: [...] }");
      cards = s.cards.map((c) => {
        if (!c || typeof c.kind !== "string" || !c.kind) throw new TypeError("Deck.restore: every card needs a non-empty string kind");
        return make(c);
      });
      carried = (s.carried ?? []).map(cloneCarried);
      extra = cloneExtra(s.extra) ?? {};
      index = clampIndex(s.index ?? 0, cards.length);
      emit({ type: "reset" });
      return cards.map((c) => c.id);
    },

    clear() {
      cards = []; carried = []; extra = {}; index = 0;
      emit({ type: "reset" });
    },

    add(card, opts) {
      if (!card || typeof card.kind !== "string" || !card.kind) throw new TypeError("Deck.add: card needs a non-empty string kind");
      const c = make(card);
      cards.push(c);
      if (opts?.select ?? true) index = cards.length - 1;
      emit({ type: "cards" });
      return c.id;
    },

    remove(id) {
      const i = deck.indexOf(id);
      if (i < 0) return;
      cards.splice(i, 1);
      // 删的在当前之前 → 当前那张卡往前挪了一位，index 跟着减；删的就是当前 → 停在原位（看下一张），到尾则退一格。
      if (i < index) index -= 1;
      index = clampIndex(index, cards.length);
      emit({ type: "cards" });
    },

    move(id, toIndex) {
      const from = deck.indexOf(id);
      if (from < 0) return;
      const to = clampIndex(toIndex, cards.length);
      if (to === from) return;
      const viewing = cards[index]?.id ?? null;
      const [c] = cards.splice(from, 1);
      cards.splice(to, 0, c!);
      if (viewing) index = deck.indexOf(viewing);
      emit({ type: "cards" });
    },

    select(i) {
      const next = clampIndex(i, cards.length);
      if (next === index) return;
      index = next;
      emit({ type: "view" });
    },

    setView(id, vp) {
      const c = deck.get(id);
      const v = cloneView(vp);
      if (!c || !v) return;
      const o = c.vp;
      if (o && o.tx === v.tx && o.ty === v.ty && o.scale === v.scale && o.rot === v.rot) return;
      c.vp = v;
      emit({ type: "view" });
    },

    setPlay(id, play) {
      const c = deck.get(id);
      const p = clonePlay(play);
      if (!c || !p) return;
      if (c.play && c.play.t === p.t && c.play.loop === p.loop && c.play.fps === p.fps) return;
      c.play = p;
      emit({ type: "view" });
    },

    setRam(id, on) {
      const c = deck.get(id); if (!c) return;
      if (on) { if (c.ram) return; c.ram = { bytes: c.bytes?.size ?? 0 }; }
      else { if (!c.ram || !c.bytes) return; c.ram = null; }
      emit({ type: "cards" });
    },
    fill(id, bytes, mime) {
      const c = deck.get(id); if (!c || !c.ram) return;
      c.bytes = bytes; if (mime) c.mime = mime;
      emit({ type: "view" });
    },

    setTarget(id, target) {
      const c = deck.get(id);
      if (!c || c.target === target) return;
      c.target = target;
      emit({ type: "cards" });
      emit({ type: "invalidate", id });
    },

    invalidate(id) {
      if (deck.indexOf(id) < 0) return;
      emit({ type: "invalidate", id });
    },

    onChange(fn) {
      listeners.add(fn);
      return () => { listeners.delete(fn); };
    },
  };
  return deck;
}
