// 参考窗的数据契约 = 容器里的**一个目录**：`.<app>/references/`，里面一份 `manifest.json` + 每张卡的字节。
// created 2026-09-29 by Claude Fable 5.1；0.2.0 改成目录制（user 2026-09-29「reference要不要自己独立的json这样是不是就是深模块窄接口了？」）
//
// 宿主的接口只有两件事：说自己叫什么（app），按名字取字节 / 存字节。命名、清单的形状、版本戳、迁移、
// 不认识的卡怎么带着——全在这个模块里。宿主不需要解析清单，也不需要知道有清单。
//
// 目录布局（0.2.0 起）：
//   .<app>/references/manifest.json        ← 清单：{ version, index, items[] }
//   .<app>/references/r<位置>.<扩展名>       ← 每张有字节的卡；位置 = 清单序号（零字节的卡不落文件，序号会跳）
//
// 兼容性：清单条目的键名沿用 WeebPaint format 2 的 refPanels（kind / src / vp），新字段可选、空值不写；
//   没有 version 的清单当 v1 读（WeebPaint 老文件里 refPanels 的那段 JSON 搬进 manifest.json 就能直接读）。
//   把老文件里的清单**搬**到这个目录是宿主的布局迁移；清单**自己**的版本演化在本模块（migrateDeckManifest）。
// 本模块只做内存里的变换：不读写文件、不联网。

import type { Card, CardPlay, CardView, CarriedItem, DeckSnapshot, NewCard } from "./deck.ts";

// ---- 清单的拍子（0.5.0 起三个数；家族格式版本纪律 = 家族根 ai-docs/20261021-format-version-discipline.md §2 / §3；user 2026-10-21「这个变成全家的版本纪律」「三级语义 同意」）----
//   物理形状：沿用整数键 `version` 当 **major**（已发出去的老库只认它，它们的 too-new 逻辑继续有效），再加两个可选整数键 `minor` / `patch`（缺 = 0）。
//   · major 比本库大 = 不可兼容 → 拒读（DeckManifestTooNewError，不降级不猜）。
//   · minor 比本库大 = 缺功能 / 行为变化 → 能读能存：不认识的键原样带回（顶层 → DeckSnapshot.extra，条目 → Card.extra），
//     并把判决（DecodedDeck.verdict = "newer-minor"）交给宿主——宿主告诉用户一次「这份是更新版本写的，这版没有的功能保存时不丢、只是看不到」，不弹窗不拦。
//   · patch 比本库大 = 可以无脑降 → "newer-patch"，静默。
//   · 比本库小：major 小 = STEPS 链式升级；minor / patch 小 = 缺的当默认（"older"）。
//   · 同 major 内只加不改；删字段 = 保留读、停止写；真要删 = major +1 + 一条 STEP + 一份冻结样本。
//   拍子史：1.0.0 = 0.2.0 目录制（WeebPaint format 2 的 refPanels 没有 version = 1）；0.4.0 加的可选 `ram` 没标过 minor（0.4.x 写的文件 minor 缺 = 0）；
//   **1.1.0 = 0.5.0**：顶层 `minor` / `patch` 两键 + 条目 `play.fps`（视频卡帧率）。
export interface DeckStamp { major: number; minor: number; patch: number }
export const DECK_MANIFEST_STAMP: Readonly<DeckStamp> = { major: 1, minor: 1, patch: 0 };
/** = DECK_MANIFEST_STAMP.major（0.2.0 起的名字，留着）。 */
export const DECK_MANIFEST_VERSION = DECK_MANIFEST_STAMP.major;
export const DECK_MANIFEST_NAME = "manifest.json";
/** 同 major 下文件拍 vs 本库拍。too-new（major 大）不在这里——它走异常。 */
export type DeckManifestVerdict = "same" | "older" | "newer-minor" | "newer-patch";

const nat = (v: unknown): number | null => (typeof v === "number" && Number.isInteger(v) && v >= 0 ? v : null);
/** 读一份清单 JSON 的拍子：version 缺 = 1（WeebPaint format 2 搬来的清单）；minor / patch 缺或非法 = 0。 */
export function readDeckStamp(json: unknown): DeckStamp {
  const o = isObj(json) ? json : {};
  const major = typeof o.version === "number" && Number.isFinite(o.version) ? Math.trunc(o.version) : 1;
  return { major, minor: nat(o.minor) ?? 0, patch: nat(o.patch) ?? 0 };
}
export function compareDeckStamp(file: DeckStamp, mine: DeckStamp = DECK_MANIFEST_STAMP): DeckManifestVerdict {
  if (file.major !== mine.major) return "older";   // major 不同只会是小（大的早在 migrate 里抛了）
  if (file.minor > mine.minor) return "newer-minor";
  if (file.minor < mine.minor) return "older";
  if (file.patch > mine.patch) return "newer-patch";
  if (file.patch < mine.patch) return "older";
  return "same";
}
/** 清单顶层本库认识的键；其余原样直通（DeckSnapshot.extra）。 */
const KNOWN_MANIFEST_KEYS: ReadonlySet<string> = new Set(["version", "minor", "patch", "index", "items"]);
/** 条目里本库认识的键；其余原样直通（Card.extra）。 */
const KNOWN_ITEM_KEYS: ReadonlySet<string> = new Set(["kind", "src", "vp", "name", "mime", "target", "origin", "play", "ram"]);
function pickExtra(o: Record<string, unknown>, known: ReadonlySet<string>): Record<string, unknown> | null {
  let out: Record<string, unknown> | null = null;
  for (const k of Object.keys(o)) if (!known.has(k)) { (out ??= {})[k] = JSON.parse(JSON.stringify(o[k] ?? null)); }
  return out;
}

/** 参考窗在容器里住的目录（不带尾斜杠）。 */
export function deckDir(app: string): string {
  if (!/^[a-z][a-z0-9-]*$/.test(app)) throw new Error(`deckDir: app name must be lowercase [a-z0-9-], got "${app}"`);
  return `.${app}/references`;
}

export interface ManifestItem {
  kind: string;
  /** 字节在容器里的文件名（含目录）。 */
  src?: string;
  vp?: CardView | null;
  name?: string;
  mime?: string;
  target?: string;
  origin?: string;
  play?: CardPlay;
  /** 0.4.0「只放内存」：不写 src，只记原文件多大（空位上给人看）。老版本库读到 = 一张没字节的卡（它再存一次会丢掉这个标记——降级，不崩）。 */
  ram?: { bytes: number };
  [extra: string]: unknown;
}
/** 清单（升到本库 major 之后的样子）。version = major；minor / patch = 文件里写的（缺 = 0）；extra = 顶层不认识的键。 */
export interface DeckManifest {
  version: number;
  minor: number;
  patch: number;
  index: number;
  items: ManifestItem[];
  extra: Record<string, unknown>;
}

export interface EncodeOptions {
  /** 宿主的名字，决定目录：`.<app>/references/`。 */
  app: string;
}
export interface DecodeOptions {
  app: string;
  /** 这个宿主画得出来的种类。其余的原样带着。 */
  knownKinds: readonly string[];
  /** 按文件名（含目录）取字节；没有就返回 null。 */
  getFile: (path: string) => Blob | null;
}
/** 解码结果可以直接喂 Deck.restore()。stamp = 文件里的拍子；verdict = 它和本库比（0.5.0）——"newer-minor" 时宿主该告诉用户一次（不弹窗不拦）。 */
export interface DecodedDeck { index: number; cards: NewCard[]; carried: CarriedItem[]; extra: Record<string, unknown>; stamp: DeckStamp; verdict: DeckManifestVerdict }

/** 清单版本（major）比这个库新：不降级、不猜，报出去。 */
export class DeckManifestTooNewError extends Error {
  readonly fileVersion: number;
  readonly libVersion: number;
  constructor(fileVersion: number, libVersion: number) {
    super(`reference manifest version ${fileVersion} is newer than this library supports (${libVersion}); refusing to read`);
    this.name = "DeckManifestTooNewError";
    this.fileVersion = fileVersion; this.libVersion = libVersion;
  }
}

// ---- 扩展名 ↔ mime（「扩展名说真话」是 WeebPaint 的既有约定）----
const EXT_BY_MIME: Record<string, string> = {
  "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif",
  "text/plain": "txt", "text/markdown": "md",
  "video/mp4": "mp4", "video/webm": "webm",
  "audio/mpeg": "mp3", "audio/mp4": "m4a", "audio/ogg": "ogg", "audio/opus": "opus", "audio/webm": "weba",
  // 0.4.0（2026-10-09，音频卡；Claude Opus 5.5）：以前这几种落成 bin
  "audio/wav": "wav", "audio/flac": "flac", "audio/aac": "aac", "video/quicktime": "mov",
};
const MIME_BY_EXT: Record<string, string> = Object.fromEntries(Object.entries(EXT_BY_MIME).map(([m, e]) => [e, m]));
/** 同一种格式的别名 mime（浏览器 / 系统各报各的）：只用来定扩展名，不参与反推。 */
const EXT_BY_MIME_ALIAS: Record<string, string> = {
  "audio/x-wav": "wav", "audio/wave": "wav", "audio/vnd.wave": "wav", "audio/x-m4a": "m4a", "audio/mp3": "mp3", "audio/x-flac": "flac", "audio/aacp": "aac",
};

/** mime → 扩展名（不带点）。不认识的图片给 "img"（WeebPaint 既有），其余不认识的给 "bin"。 */
export function extForMime(mime: string): string {
  const base = (mime || "").split(";")[0]!.trim().toLowerCase();
  return EXT_BY_MIME[base] ?? EXT_BY_MIME_ALIAS[base] ?? (base.startsWith("image/") ? "img" : "bin");
}
/** 文件名 → mime（按扩展名猜）。猜不出 → ""。 */
export function mimeForName(name: string): string {
  const m = /\.([A-Za-z0-9]+)$/.exec(name || "");
  return m ? (MIME_BY_EXT[m[1]!.toLowerCase()] ?? "") : "";
}
function extOfName(name: string): string {
  const m = /\.([A-Za-z0-9]+)$/.exec(name || "");
  return m ? m[1]!.toLowerCase() : "bin";
}
const fileName = (dir: string, position: number, ext: string): string => `${dir}/r${position}.${ext}`;

// ---- 清单自己的版本演化（CatsUp 立宪 §7 同款：纯函数、链式升级、比库新就拒）----
type Step = (json: Record<string, unknown>) => Record<string, unknown>;
/** STEPS[v] = 从 v 升到 v+1。加迁移 = 在这里登记一条 + 在 test/fixtures/ 冻结一份旧版清单。 */
const STEPS: Record<number, Step> = {};

function isObj(x: unknown): x is Record<string, unknown> { return !!x && typeof x === "object" && !Array.isArray(x); }

/** 把任何版本的清单升到当前 major。缺 version 视为 1；不是对象 → 空清单。minor / patch 照文件（经过 STEP 的以 STEP 写的为准，缺 = 0）；顶层不认识的键进 extra。 */
export function migrateDeckManifest(json: unknown): DeckManifest {
  const src = isObj(json) ? json : {};
  let v = readDeckStamp(src).major;
  if (v > DECK_MANIFEST_VERSION) throw new DeckManifestTooNewError(v, DECK_MANIFEST_VERSION);
  let cur: Record<string, unknown> = src;
  while (v < DECK_MANIFEST_VERSION) {
    const step = STEPS[v];
    if (!step) throw new Error(`migrateDeckManifest: no step registered for v${v} → v${v + 1}`);
    cur = step(cur); v++;
    if (cur.version !== v) throw new Error(`migrateDeckManifest: step v${v - 1}→v${v} did not set version`);
  }
  const items = Array.isArray(cur.items) ? (cur.items as unknown[]).filter((it): it is ManifestItem => isObj(it) && typeof it.kind === "string" && !!it.kind) : [];
  const index = typeof cur.index === "number" && Number.isFinite(cur.index) ? Math.trunc(cur.index) : 0;
  const { minor, patch } = readDeckStamp(cur);
  return { version: DECK_MANIFEST_VERSION, minor, patch, index, items, extra: pickExtra(cur, KNOWN_MANIFEST_KEYS) ?? {} };
}

function readView(x: unknown): CardView | null {
  if (!isObj(x)) return null;
  const { tx, ty, scale, rot } = x;
  const ok = [tx, ty, scale, rot].every((n) => typeof n === "number" && Number.isFinite(n));
  return ok ? { tx: tx as number, ty: ty as number, scale: scale as number, rot: rot as number } : null;
}
function readPlay(x: unknown): CardPlay | null {
  if (!isObj(x) || typeof x.t !== "number" || !Number.isFinite(x.t)) return null;
  const fps = typeof x.fps === "number" && Number.isFinite(x.fps) && x.fps > 0 ? x.fps : undefined;
  return fps !== undefined ? { t: x.t, loop: !!x.loop, fps } : { t: x.t, loop: !!x.loop };
}
const str = (x: unknown): string => (typeof x === "string" ? x : "");

/** 从容器里读回牌组。目录里没有 manifest.json → 空牌组（不是错）。清单不是合法 JSON → 抛错（不静默当空）。 */
export async function decodeDeck(o: DecodeOptions): Promise<DecodedDeck> {
  const dir = deckDir(o.app);
  const blob = o.getFile(`${dir}/${DECK_MANIFEST_NAME}`);
  if (!blob) return { index: 0, cards: [], carried: [], extra: {}, stamp: { ...DECK_MANIFEST_STAMP }, verdict: "same" };
  let json: unknown;
  try { json = JSON.parse(await blob.text()); }
  catch (e) { throw new Error(`decodeDeck: ${dir}/${DECK_MANIFEST_NAME} is not valid JSON: ${String((e as Error).message)}`); }
  return decodeDeckFromJson(json, o);
}

/** 清单已经在手上（宿主从别处搬来的、或测试）时用这个。 */
export function decodeDeckFromJson(manifestJson: unknown, o: Pick<DecodeOptions, "knownKinds" | "getFile">): DecodedDeck {
  const stamp = readDeckStamp(manifestJson);   // 文件原来的拍子（判决按它；major 比本库新的在下一行抛）
  const m = migrateDeckManifest(manifestJson);
  const verdict = compareDeckStamp(stamp);
  const known = new Set(o.knownKinds);
  const cards: NewCard[] = [];
  const carried: CarriedItem[] = [];
  let index = 0, indexSet = false;
  m.items.forEach((raw, at) => {
    if (!known.has(raw.kind)) {
      const files: CarriedItem["files"] = {};
      const s = str(raw.src) ? o.getFile(str(raw.src)) : null;
      if (s) files.src = s;
      carried.push({ at, item: JSON.parse(JSON.stringify(raw)) as Record<string, unknown>, files });
      return;
    }
    const ram = isObj(raw.ram) && typeof raw.ram.bytes === "number" && Number.isFinite(raw.ram.bytes) ? { bytes: raw.ram.bytes } : null;
    const src = ram ? "" : str(raw.src);
    const bytes = src ? o.getFile(src) : null;
    if (at === m.index) { index = cards.length; indexSet = true; }
    cards.push({
      kind: raw.kind,
      name: str(raw.name),
      bytes,
      mime: str(raw.mime) || bytes?.type || mimeForName(src),
      target: str(raw.target) || null,
      vp: readView(raw.vp),
      play: readPlay(raw.play),
      origin: str(raw.origin) || null,
      ram,
      extra: pickExtra(raw, KNOWN_ITEM_KEYS),
    });
  });
  if (!indexSet) index = Math.max(0, Math.min(cards.length - 1, m.index));
  return { index, cards, carried, extra: m.extra, stamp, verdict };
}

/** 把牌组编成容器里的一组文件：`.<app>/references/manifest.json` + 每张卡的字节。宿主原样存。 */
export function encodeDeck(s: DeckSnapshot, o: EncodeOptions): Map<string, Blob> {
  const dir = deckDir(o.app);
  type Slot = { card: Card } | { carried: CarriedItem };
  const slots: Slot[] = s.cards.map((card) => ({ card }));
  for (const c of [...s.carried].sort((a, b) => a.at - b.at)) {
    const at = Math.max(0, Math.min(slots.length, Math.trunc(c.at) || 0));
    slots.splice(at, 0, { carried: c });
  }
  const files = new Map<string, Blob>();
  const items: ManifestItem[] = [];
  let index = 0;
  const viewing = s.cards[s.index] ?? null;
  slots.forEach((slot, position) => {
    if ("carried" in slot) {
      // 不认识的卡：条目原文照写；字节按新位置重新起名（否则会和认识的卡撞名）
      const item = JSON.parse(JSON.stringify(slot.carried.item)) as ManifestItem;
      const src = slot.carried.files.src;
      if (src) { const n = fileName(dir, position, extOfName(str(item.src))); files.set(n, src); item.src = n; }
      else delete item.src;   // 字节早就没了：别留一个指向不存在文件的名字
      items.push(item);
      return;
    }
    const c = slot.card;
    if (c === viewing) index = position;
    // 键的顺序固定：kind, src, vp 在前（= WeebPaint format 2），新字段在后；空值不写。
    const item: ManifestItem = { kind: c.kind };
    if (c.bytes && !c.ram) { const n = fileName(dir, position, extForMime(c.mime || c.bytes.type)); files.set(n, c.bytes); item.src = n; }   // 只放内存 = 字节不进文件
    item.vp = c.vp ? { tx: c.vp.tx, ty: c.vp.ty, scale: c.vp.scale, rot: c.vp.rot } : null;
    if (c.name) item.name = c.name;
    if (c.mime && (!item.src || mimeForName(item.src) !== c.mime.split(";")[0]!.trim().toLowerCase())) item.mime = c.mime;
    if (c.target) item.target = c.target;
    if (c.origin) item.origin = c.origin;
    if (c.play) item.play = c.play.fps ? { t: c.play.t, loop: c.play.loop, fps: c.play.fps } : { t: c.play.t, loop: c.play.loop };
    if (c.ram) item.ram = { bytes: c.ram.bytes };
    // 条目里不认识的键（更新版本的库写的）原样带回，排在已知键后面；已知键永远赢
    if (c.extra) for (const k of Object.keys(c.extra)) if (!KNOWN_ITEM_KEYS.has(k)) item[k] = c.extra[k];
    items.push(item);
  });
  // 拍子写在最前（人眼一看就知道多新）；顶层不认识的键夹在中间原样带回；index / items 殿后。写入器只写本库的拍，直通的键里不含拍子本身。
  const manifest: Record<string, unknown> = { version: DECK_MANIFEST_STAMP.major, minor: DECK_MANIFEST_STAMP.minor, patch: DECK_MANIFEST_STAMP.patch };
  for (const k of Object.keys(s.extra ?? {})) if (!KNOWN_MANIFEST_KEYS.has(k)) manifest[k] = s.extra[k];
  manifest.index = index; manifest.items = items;
  const out = new Map<string, Blob>();
  out.set(`${dir}/${DECK_MANIFEST_NAME}`, new Blob([JSON.stringify(manifest)], { type: "application/json" }));
  for (const [n, b] of files) out.set(n, b);
  return out;
}
