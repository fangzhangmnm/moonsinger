// select-field —— 下拉标准件：原生 <select> 的替身（一颗按钮 + popup-menu compact 弹层）。
// 0.3.0 起第六件。added 2026-11-12 by Claude Opus 5.5（MoonSinger小弟；MoonSinger 施工单 7-T，user 2026-11-12「当然要抽库…可以跳一个小版本」）。
// 来历：WeebPaint v0.14.86 `src/ui/select-field.ts`（created 2026-09-02 by Claude Fable 5.1，UI 纪元 C6）→ 这里。搬，不改语义、不改接口名字；
//   摘掉了画画软件自己的两样：Vue 的包装（SelectFieldVue，留在画画软件）、右下角小三角取自画画软件的 icon.ts（这里内联同一枚形状）。
//
// 为什么不用原生 <select>（WeebPaint 考古 T6）：它的打开态归浏览器——iPad 弹系统的层（系统字体、夜间白底白字、装不了 SVG 图标）。
// 用法：静态节点 = 页面里一个 <button>，mountSelectField(el, …)（这里补上文字和角标）；现建 = createSelectField(…)。
// 受控：当前值由宿主持有（value()），钮面永远从它算；值在外面改了 → refresh()。
// 钮面三档（face）：
//   "label"（默认；有地方，写全名）/ "short"（定宽：写 SelectItem.short 缩写，没缩写退回全名、放不下省略号）
//   / "icon"（只画当前项的图标；那一项没图标 = 退回缩写，钮面永不空白）。弹层里永远是全名（+ 图标）。
//   定宽的「宽」= 这个下拉自己量：所有项缩写里最宽的一条 + 自己的左右内边距 / 边框（+ 图标位）——换项不抖，也不为别的下拉留空；
//   量不到（还没进页面 / 没有布局环境）= 留 CSS 兜底宽 --select-fixed-w。
// 分组：SelectItem.group 换了就在弹层里插一行组名（不可点）；当前项打勾；disabled 的项灰着点不动。
// 键盘：弹层的上下键 / 回车 / Esc 归 popup-menu（项都是按钮）。层级：band 交给 popup-menu（面板里传 "modal" 压过面板）。
// 样式：`workbench-elements.css` 的 `.select-field*`（排版 + 角标）；按钮的皮（底色 / 边框 / 圆角 / 字号）归宿主自己的类。

import { togglePopupMenu, type PopupBand, type PopupMenuItem } from "./popup-menu.ts";
import { iconHtml } from "./icon.ts";

/** 一项：value = 宿主的值；label = 全名（弹层里写的）；short = 定宽钮面的缩写；icon = sprite 的 symbol id；group = 组名（换了就插组标题）。 */
export interface SelectItem { value: string; label: string; short?: string; icon?: string; group?: string; disabled?: boolean }
export type SelectFace = "label" | "short" | "icon";
export interface SelectFieldOpts {
  items: () => SelectItem[];
  /** 受控：当前值由宿主持有。 */
  value: () => string;
  onChange: (v: string) => void;
  /** 弹层压在哪一层（面板 / 弹窗里传 "modal"）；默认 menu。 */
  band?: PopupBand;
  align?: "left" | "right";
  ariaLabel?: string;
  /** 钮面档（见文件头）；默认 label。 */
  face?: SelectFace;
}
export interface SelectField {
  readonly el: HTMLElement;
  readonly value: string;
  /** 值在外面改了 → 重画钮面。 */
  refresh(): void;
  dispose(): void;
}

/** 右下角小三角（「有三角 = 有菜单」；和画画软件工具条变体槽同一颗形状）。 */
const CARET_SVG = `<svg viewBox="0 0 8 8" aria-hidden="true"><path d="M7.2 2.8 V7.2 H2.8 Z" fill="currentColor" stroke="none"/></svg>`;
/** 组标题在弹层里的 id 前缀（点它 = 不做事、不收）。 */
const GROUP_PREFIX = "__group:";

/** 一组项 + 当前值 → 弹层的项（换组插一行组标题；当前项打勾）。纯函数。 */
export function selectMenuItems(items: readonly SelectItem[], cur: string): PopupMenuItem[] {
  const out: PopupMenuItem[] = [];
  let group: string | undefined;
  for (const it of items) {
    if (it.group !== group) { group = it.group; if (group) out.push({ id: `${GROUP_PREFIX}${group}`, label: group, header: true }); }
    out.push({ id: it.value, label: it.label, icon: it.icon, checked: it.value === cur, disabled: it.disabled });
  }
  return out;
}

// 量文字宽用的隐藏 span（全库一只，挂 body；只量缩写宽度）
let _measurerEl: HTMLElement | null = null;
function _measurer(): HTMLElement {
  if (!_measurerEl || !_measurerEl.isConnected) {
    _measurerEl = document.createElement("span");
    _measurerEl.setAttribute("aria-hidden", "true");
    _measurerEl.style.cssText = "position:absolute;left:-9999px;top:0;visibility:hidden;white-space:nowrap;pointer-events:none;";
    document.body.appendChild(_measurerEl);
  }
  return _measurerEl;
}

export function mountSelectField(el: HTMLElement, opts: SelectFieldOpts): SelectField {
  const face: SelectFace = opts.face ?? "label";
  el.classList.add("select-field");
  el.classList.toggle("select-field--fixed", face === "short");
  el.classList.toggle("select-field--icon", face === "icon");
  el.dataset.face = face;
  el.setAttribute("aria-haspopup", "listbox");
  if (opts.ariaLabel) el.setAttribute("aria-label", opts.ariaLabel);
  // 已有文字位（同一个节点第二次 mount）就复用：扫直系子节点（不用 querySelector）
  let label = ([...el.childNodes] as HTMLElement[]).find((n) => (n.className || "").split(" ").includes("select-field-label")) ?? null;
  if (!label) {
    label = document.createElement("span");
    label.className = "select-field-label";
    el.appendChild(label);
    const caret = document.createElement("span");
    caret.className = "select-field-caret";
    caret.innerHTML = CARET_SVG;
    el.appendChild(caret);
  }
  let iconEl: HTMLElement | null = null;   // 钮面图标位
  let sizedKey = "";                        // 上次定宽量的是哪组缩写（项没变就不重量）
  const sizeFixed = (items: SelectItem[]) => {
    if (face !== "short" || !el.isConnected) return;
    const anyIcon = items.some((it) => !!it.icon);
    const key = items.map((it) => it.short ?? it.label).join("\u0001") + (anyIcon ? "\u0002" : "");
    if (key === sizedKey) return;
    const cs = getComputedStyle(el);
    const m = _measurer();
    m.style.fontFamily = cs.fontFamily; m.style.fontSize = cs.fontSize; m.style.fontWeight = cs.fontWeight; m.style.fontStyle = cs.fontStyle; m.style.letterSpacing = cs.letterSpacing;
    let maxW = 0;
    for (const it of items) { m.textContent = it.short ?? it.label; maxW = Math.max(maxW, m.getBoundingClientRect().width); }
    if (!(maxW > 0)) return;   // 量不到 → 留 CSS 兜底宽
    sizedKey = key;
    const px = (v: string) => parseFloat(v) || 0;
    const chrome = px(cs.paddingLeft) + px(cs.paddingRight) + px(cs.borderLeftWidth) + px(cs.borderRightWidth);
    const iconW = anyIcon ? (iconEl?.getBoundingClientRect().width || 18) + px(cs.columnGap || cs.gap) : 0;
    el.style.width = `${Math.ceil(maxW + chrome + iconW)}px`;
  };
  const refresh = () => {
    const v = opts.value();
    const items = opts.items();
    const cur = items.find((it) => it.value === v);
    const full = cur?.label ?? v;
    const brief = cur?.short ?? full;
    el.dataset.value = v;   // 当前值落在节点上（测试 / 探针读；只图标档没文字可读）
    if (cur?.icon) {
      if (!iconEl) { iconEl = document.createElement("span"); iconEl.className = "select-field-icon"; el.insertBefore(iconEl, label); }
      iconEl.innerHTML = iconHtml(cur.icon);
    } else if (iconEl) { iconEl.remove(); iconEl = null; }
    // 文字：label 档全名；short 档缩写；icon 档只在没图标可画时退回缩写
    const text = face === "label" ? full : (face === "short" || !cur?.icon) ? brief : "";
    label!.textContent = text;
    label!.hidden = text === "";
    sizeFixed(items);
  };
  const onClick = (e: Event) => {
    e.stopPropagation();
    togglePopupMenu<string>({
      anchor: el, variant: "compact", band: opts.band ?? "menu", align: opts.align ?? "left", offsetY: 4,
      items: () => selectMenuItems(opts.items(), opts.value()),
      onPick: (v) => { if (v.startsWith(GROUP_PREFIX)) return "keep"; opts.onChange(v); refresh(); },
    });
  };
  el.addEventListener("click", onClick);
  refresh();
  return {
    el,
    get value() { return opts.value(); },
    refresh,
    dispose() { el.removeEventListener("click", onClick); },
  };
}

/** 现建一个下拉按钮。 */
export function createSelectField(opts: SelectFieldOpts & { id?: string; className?: string }): SelectField {
  const b = document.createElement("button");
  b.type = "button";
  if (opts.id) b.id = opts.id;
  if (opts.className) b.className = opts.className;
  return mountSelectField(b, opts);
}
